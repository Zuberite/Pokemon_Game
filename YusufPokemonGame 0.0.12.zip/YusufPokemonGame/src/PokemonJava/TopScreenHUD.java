package PokemonJava;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class TopScreenHUD {
	
	
	@FXML
	Canvas gameCanvas;

	GraphicsContext gc;
	
	double x = 43;
	double y = 117-53;
	String imageName = "images/CharmanderBack.png";
	Image image = new Image(imageName);
	
	
	
	
	public TopScreenHUD(GraphicsContext gc, Canvas gameCanvas) {
		super();
		this.gameCanvas = gameCanvas;
		this.gc = gc;
	}

	public void display(String[] playerPokemonStats, String[] OpponentPokemonStats, int[] playerPokemonDynamicStats, int[] OpponentPokemonDynamicStats) {
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[0], 150, 85);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[5], 232, 85);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(Integer.toString(playerPokemonDynamicStats[0]), 210, 105);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[7], 230, 105);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(OpponentPokemonStats[0], 5, 36);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(OpponentPokemonStats[5], 85, 36);
		
		
		
	}
	
	public void move(String[] playerPokemonStats) {
		
		this.x = Integer.parseInt(playerPokemonStats[3]);
		this.y = Integer.parseInt(playerPokemonStats[4]);
		this.imageName = playerPokemonStats[2];
		
		this.image = new Image(imageName);
		
		this.gc.drawImage(this.image, this.x, this.y); 
		
	}

}
