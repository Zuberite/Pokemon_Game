package PokemonJava;

import java.nio.file.Paths;
import java.util.ArrayList;

import javafx.animation.AnimationTimer;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.*;
import javafx.stage.Stage;

public class PokemonJavaController {
	@FXML
	Canvas gameCanvas;

	Scene gameScene;

	GraphicsContext gc;
	
	@FXML
	MenuItem m1;

	public String gameScreen = "StartMenu";
	public String playerPokemon1Stats[] = { "Charmander", "Fire", "images/CharmanderBack.png", "43", "64", "5", "Red",
			"39", "52", "43", "60", "50", "65", "Scratch", "images/MoveNormal.png", "40", "100", "10", "Ember",
			"images/MoveFire.png", "40", "100", "3", "", "images/MoveTypeNull.png", "", "", "", "",
			"images/MoveTypeNull.png", "", "", "", "images/SummaryMoveNormal.png", "images/SummaryMoveFire.png", "", "",
			"images/PartyCharmander.png", "images/CharmanderFront.png", "Normal", "Fire", "", "", "Physical", "Special",
			"", "" };
	public String opponentPokemon1Stats[] = { "Squirtle", "Water", "images/SquirtleFront.png", "175", "25", "7", "44",
			"48", "65", "50", "64", "43", "Tackle", "Normal", "40", "100", "15", "Water Gun", "Water", "40", "100", "5",
			"No Move", "Null", "0", "0", "0", "No Move", "Null", "0", "0", "0", "Physical", "Special", "", "" };
	public int playerPokemon1DynamicStats[] = { 39, 10, 3, 0, 0, 1, 1 };
	public int opponentPokemon1DynamicStats[] = { 44, 15, 5, 0, 0, 1 };

	public String playerPokemon2Stats[] = { "Bulbasaur", "Grass", "images/BulbasaurBack.png", "43", "73", "6", "Red",
			"45", "49", "49", "65", "65", "45", "Tackle", "images/MoveNormal.png", "40", "100", "15", "Vine Whip",
			"images/MoveGrass.png", "45", "100", "3", "", "images/MoveTypeNull.png", "", "", "", "",
			"images/MoveTypeNull.png", "", "", "", "images/SummaryMoveNormal.png", "images/SummaryMoveGrass.png", "",
			"", "images/PartyBulbasaur.png", "images/BulbasaurFront.png", "Normal", "Grass", "", "", "Physical",
			"Physical", "", "" };
	public int playerPokemon2DynamicStats[] = { 45, 15, 3, 0, 0, 2, 2 };
	public int currentPokemonID = 1;
	public int currentPokemonSummaryID = 1;

	public int textBoxTimer = 250;
	public int dialogueID = 1;
	public int itemAmount[] = { 5, 3, 1 };
	public boolean itemAppliedOrPokemonSwapped = false;
	public boolean damageCalculated = false;
	public int turnMoveAndDamageHolder[] = new int[7];
	public String playerPokemonMoveName;
	public String opponentPokemonMoveName;
	public boolean noPP = false;
	public boolean noSwapAllowed = false;
	public boolean pokemon2NotFainted  = true;
	public boolean gameOver = false;
	public boolean playerWin = false;
	public boolean reset = false;
	public boolean menuSoundPlayed = false;
	public boolean battleSoundPlayed = false;
	public boolean processing = false;
	static Stage secondaryStage;
	

	public void getScene(Stage primaryStage) {
		gameScene = primaryStage.getScene();
	}
	
	public void menuClickHandler(ActionEvent evt) {

		MenuItem clickedMenu = (MenuItem) evt.getTarget();
		String menuLabel = clickedMenu.getText();
		System.out.println(menuLabel);
		
		
		if ("How To Play".equals(menuLabel)) {
			openHowToWindow();
		}
		
		
	}
	
	private void openHowToWindow() {
		try {
			// load the pop up you created
			Pane howTo = (Pane) FXMLLoader.load(getClass().getResource("HowToPlay.fxml"));

			// create a new scene
			Scene howToScene = new Scene(howTo, 318, 412);

			// create new stage to put scene in
			secondaryStage = new Stage();
			secondaryStage.setScene(howToScene);
			secondaryStage.setResizable(false);
			secondaryStage.showAndWait();
			secondaryStage.setTitle("Old Dusty Manual");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void closeWindowButtonClickHandler(ActionEvent evt) {
		// make sure the name of the stage is same as in openHowToWindow()
		secondaryStage.close();
	}

	public void gameLoop() {

		ArrayList<String> input = new ArrayList<String>(); // for monkey's input
		gc = gameCanvas.getGraphicsContext2D();
		Image background = new Image("images/background.png"); // creates an instance of a image "background"
		Image backgroundTop = new Image("images/backgroundTop.png");
		Image textBoxImage = new Image("images/TextBox.png");
		Image bottomBackground = new Image("images/BottomBackground.png"); // creates an instance of a image
																			// "background"
		Image fightBackground = new Image("images/FightBackground.png"); // creates an instance of a image "background"
		Image pokemonBackground = new Image("images/PartyBackground.png"); // creates an instance of a image
																			// "background"
		Image bagBackground = new Image("images/BagBackground.jpeg"); // creates an instance of a image "background"
		Image playerHealthBar = new Image("images/HPPlayerBar.png");
		Image enemyHealthBar = new Image("images/HPEnemyBar.png");
		Image pokemon2 = new Image("images/SquirtleFront.png");
		Image partySlotImage = new Image("images/PartySlotTemplate.png");
		Image summaryBackground = new Image("images/SummaryScreen.png");
		Media mainMenuMusicName = new Media (Paths.get("src/sounds/StartScreenMusic.mp3").toUri().toString());
		MediaPlayer mainMenuMusic = new MediaPlayer(mainMenuMusicName);
		Media battleMenuMusicName = new Media (Paths.get("src/sounds/BattleMusic.mp3").toUri().toString());
		MediaPlayer battleMenuMusic = new MediaPlayer(battleMenuMusicName);

		Cursor cursor = new Cursor(gc, gameCanvas, input);
		ItemHUD itemHUD = new ItemHUD(gc, gameCanvas);
		PartyHUD partyHUD = new PartyHUD(gc, gameCanvas);
		FightHUD fightHUD = new FightHUD(gc, gameCanvas);
		TopScreenHUD topScreenHUD = new TopScreenHUD(gc, gameCanvas);
		SummaryHUD summaryHUD = new SummaryHUD(gc, gameCanvas);
		BattleMechanics battleMechanics = new BattleMechanics(gc, gameCanvas);
		TextBox textBox = new TextBox(gc, gameCanvas);
		endScreenHud endScreenHud = new endScreenHud(gc,gameCanvas);
		
		animationProcessor bike = new animationProcessor();
        Image[] bikeImageArray = new Image[6];
        for (int i = 1; i < 7; i++)
            bikeImageArray[i-1] = new Image( "images/bike" + i + ".png" );
        bike.frames = bikeImageArray;
        bike.duration = 0.100;

		// checks for key pressed and adds it to input
		gameScene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent e) {
				String code = e.getCode().toString();
				if (!input.contains(code))
					input.add(code);
			}
		});

		// check for key released and removes the key from input
		gameScene.setOnKeyReleased(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent e) {
				String code = e.getCode().toString();
				if (input.contains(code))
					input.remove(code);
			}
		});
		
		 final long startNanoTime = System.nanoTime();

		new AnimationTimer() {
			// actual game loop that repeats
			
			
			@Override
			public void handle(long currentNanoTime) {
				gc.clearRect(0, 0, gameCanvas.getWidth(), gameCanvas.getHeight());
				
				if (gameOver == false) {
				// clear canvas each frame
				
				
				
				
				if (gameScreen != "StartMenu") {
				menuSoundPlayed = false;
				battleSoundPlayed = true;
				
				
				mainMenuMusic.stop();
				battleMenuMusic.play();
				// draw background image
				gc.drawImage(background, 0, 0);
				gc.drawImage(backgroundTop, 0, 0);
				gc.drawImage(textBoxImage, 3, 117);
				gc.drawImage(playerHealthBar, 136, 70);
				gc.drawImage(enemyHealthBar, 0, 21);
				gc.drawImage(pokemon2, 175, 25);
				textBox.display();
				

				if (currentPokemonID == 1) {
					topScreenHUD.display(playerPokemon1Stats, opponentPokemon1Stats, playerPokemon1DynamicStats,
							opponentPokemon1DynamicStats);
					topScreenHUD.move(playerPokemon1Stats);
				} else if (currentPokemonID == 2) {
					topScreenHUD.display(playerPokemon2Stats, opponentPokemon1Stats, playerPokemon2DynamicStats,
							opponentPokemon1DynamicStats);
					topScreenHUD.move(playerPokemon2Stats);
				}
				
				
				

				if (gameScreen == "MainMenu") {
					
					 if (processing == false) {
					gc.drawImage(bottomBackground, 0, 161);
					gameScreen = cursor.move(gameScreen);
					 }
					
					textBox.setTextToLoad2("");
					textBox.setTextToLoad3("");
					
					if (currentPokemonID == 1) {
						textBox.setTextToLoad1("What Will Charmander Do?");
					} else if (currentPokemonID == 2) {
						textBox.setTextToLoad1("What Will Bulbasaur Do?");
					}
					
				
					
					if (noSwapAllowed == false) {
						
						if (playerPokemon1DynamicStats[0] == 0) {
							textBoxTimer -=1;
							
							
							if (textBoxTimer > 0) {
								textBox.setTextToLoad1("Charmander Fainted.");
								processing = true;
							}
							else {
							gameScreen = "Swap";
							if (reset == false) {
							textBoxTimer = 250;
							}
							reset = true;
							processing = false;
							cursor.setLocationXSwap(1);
							}
							
						}
						else if (playerPokemon2DynamicStats[0] == 0) {
							textBoxTimer -=1;
							
						
							if (textBoxTimer > 0) {
								textBox.setTextToLoad1("Bulbasaur Fainted.");
								processing = true;
							}
							else {
							gameScreen = "Swap";
							if (reset == false) {
								textBoxTimer = 250;
								}
							reset = true;
							processing = false;
							cursor.setLocationXSwap(1);
							pokemon2NotFainted  = false;
							}
						}
						}
					
					
					if (opponentPokemon1DynamicStats[0] == 0) {
						textBoxTimer -= 1;
						if (dialogueID == 1) {
						if (textBoxTimer > 0) {
							textBox.setTextToLoad1("The Opposing Squirtle Fainted.");
							noSwapAllowed = false;
							processing = true;
						}
						else {
							textBoxTimer = 250;
							dialogueID = 2;
							
						}
						}
						else if (dialogueID == 2) {
							if (textBoxTimer > 0) {
								textBox.setTextToLoad1("You Won!");
							}
							else {
								textBoxTimer = 250;
								dialogueID = 1;
								gameOver = true;
								gameScreen = "EndMenu";
								processing = false;
							}
						}
						
						
					
					}
					
					if (playerPokemon1DynamicStats[0] == 0 && playerPokemon2DynamicStats[0] == 0) {
						
						textBoxTimer -= 1;
						if (dialogueID == 1) {
						if (textBoxTimer > 0) {
							if (currentPokemonID == 1) {
								textBox.setTextToLoad1("Charmander Fainted.");
							}
							else if (currentPokemonID == 2 ) {
								textBox.setTextToLoad1("Bulbasaur Fainted.");
							}
							
						}
						
						else {
							textBoxTimer = 250;
							dialogueID = 2;
						}
						
						
						
						}
						
						else if (dialogueID == 2) {
								if (textBoxTimer > 0) {
									textBox.setTextToLoad1("Traniner Ran out of pokemon!");
									textBox.setTextToLoad2("Trainer Blacked Out!");
								}
								else {
									textBoxTimer = 250;
									dialogueID = 1;
									gameOver = true;
									gameScreen = "EndMenu";
								}
						
					}
					}
					
					
					
					

				} else if (gameScreen == "Fight") {

					gc.drawImage(fightBackground, 0, 161);
					if (currentPokemonID == 1) {
						fightHUD.move(playerPokemon1Stats);
						fightHUD.display(playerPokemon1Stats, playerPokemon1DynamicStats);
					} else if (currentPokemonID == 2) {
						fightHUD.move(playerPokemon2Stats);
						fightHUD.display(playerPokemon2Stats, playerPokemon2DynamicStats);
					}
					gameScreen = cursor.move(gameScreen);
				}

				else if (gameScreen == "BattleMechanics") {

					textBoxTimer -= 1;

					if (damageCalculated == false) {

						if (currentPokemonID == 1) {
							turnMoveAndDamageHolder = battleMechanics.fightMechanics(cursor, playerPokemon1Stats,
									opponentPokemon1Stats, itemAppliedOrPokemonSwapped);

							if (itemAppliedOrPokemonSwapped == false) {
								if (turnMoveAndDamageHolder[3] == 1) {
									playerPokemonMoveName = playerPokemon1Stats[13];
									if (playerPokemon1DynamicStats[1] == 0) {
										noPP = true;
									} else {
										playerPokemon1DynamicStats[1] = playerPokemon1DynamicStats[1] - 1;
									}
								} else if (turnMoveAndDamageHolder[3] == 2) {
									playerPokemonMoveName = playerPokemon1Stats[18];
									if (playerPokemon1DynamicStats[2] == 0) {
										noPP = true;
									} else {
										playerPokemon1DynamicStats[2] = playerPokemon1DynamicStats[2] - 1;
									}
								} else if (turnMoveAndDamageHolder[3] == 3) {
									playerPokemonMoveName = playerPokemon1Stats[23];
									if (playerPokemon1DynamicStats[3] == 0) {
										noPP = true;
									} else {
										playerPokemon1DynamicStats[3] = playerPokemon1DynamicStats[3] - 1;
									}
								} else if (turnMoveAndDamageHolder[3] == 4) {
									playerPokemonMoveName = playerPokemon1Stats[28];
									if (playerPokemon1DynamicStats[4] == 0) {
										noPP = true;
									} else {
										playerPokemon1DynamicStats[4] = playerPokemon1DynamicStats[4] - 1;
									}
								}
							}
							
						} else if (currentPokemonID == 2) {
							turnMoveAndDamageHolder = battleMechanics.fightMechanics(cursor, playerPokemon2Stats,
									opponentPokemon1Stats, itemAppliedOrPokemonSwapped);
							if (itemAppliedOrPokemonSwapped == false) {
								if (turnMoveAndDamageHolder[3] == 1) {
									playerPokemonMoveName = playerPokemon2Stats[13];
									if (playerPokemon2DynamicStats[1] == 0) {
										noPP = true;
									} else {
										playerPokemon2DynamicStats[1] = playerPokemon2DynamicStats[1] - 1;
									}
								} else if (turnMoveAndDamageHolder[3] == 2) {
									playerPokemonMoveName = playerPokemon2Stats[18];
									if (playerPokemon2DynamicStats[2] == 0) {
										noPP = true;
									} else {
										playerPokemon2DynamicStats[2] = playerPokemon2DynamicStats[2] - 1;
									}
								} else if (turnMoveAndDamageHolder[3] == 3) {
									playerPokemonMoveName = playerPokemon2Stats[23];
									if (playerPokemon2DynamicStats[3] == 0) {
										noPP = true;
									} else {
										playerPokemon2DynamicStats[3] = playerPokemon2DynamicStats[3] - 1;
									}

								} else if (turnMoveAndDamageHolder[3] == 4) {
									playerPokemonMoveName = playerPokemon2Stats[28];
									if (playerPokemon2DynamicStats[4] == 0) {
										noPP = true;
									} else {
										playerPokemon2DynamicStats[4] = playerPokemon2DynamicStats[4] - 1;
									}
								}
							}
						}

						if (turnMoveAndDamageHolder[4] == 1) {
							opponentPokemonMoveName = opponentPokemon1Stats[12];
							opponentPokemon1DynamicStats[1] = opponentPokemon1DynamicStats[1] - 1;
						} else if (turnMoveAndDamageHolder[4] == 2) {
							opponentPokemonMoveName = opponentPokemon1Stats[17];
							opponentPokemon1DynamicStats[2] = opponentPokemon1DynamicStats[2] - 1;
						} else if (turnMoveAndDamageHolder[4] == 3) {
							opponentPokemonMoveName = opponentPokemon1Stats[22];
							opponentPokemon1DynamicStats[3] = opponentPokemon1DynamicStats[3] - 1;
						} else if (turnMoveAndDamageHolder[4] == 4) {
							opponentPokemonMoveName = opponentPokemon1Stats[27];
							opponentPokemon1DynamicStats[4] = opponentPokemon1DynamicStats[4] - 1;
						}

						damageCalculated = true;
					}
					
					


					 if (turnMoveAndDamageHolder[0] == 1 && itemAppliedOrPokemonSwapped == false && damageCalculated == true && noPP == false) {
						
						 
						 
						 
						 if (dialogueID == 1) {

							if (textBoxTimer > 0) {
								if (currentPokemonID == 1) {
									textBox.setTextToLoad1("Charmander used " + playerPokemonMoveName);
									textBox.setTextToLoad2("");
									textBox.setTextToLoad3("");
								} else if (currentPokemonID == 2) {
									textBox.setTextToLoad1("Bulbasaur used " + playerPokemonMoveName);
									textBox.setTextToLoad2("");
									textBox.setTextToLoad3("");
								}
							} else {
								textBoxTimer = 250;
								if (turnMoveAndDamageHolder[5] == 1) {
									dialogueID = 3;
								}
								else {
									dialogueID = 2;
								}
								if (opponentPokemon1DynamicStats[0] - turnMoveAndDamageHolder[1] < 0) {
									opponentPokemon1DynamicStats[0] = 0;
								} else {
									opponentPokemon1DynamicStats[0] = opponentPokemon1DynamicStats[0]
											- turnMoveAndDamageHolder[1];
								}
							}
						}
						
						 
						 else if (dialogueID == 3) {
							 if (textBoxTimer > 0) {
							 textBox.setTextToLoad1("A Critical Hit");
								textBox.setTextToLoad2("");
								textBox.setTextToLoad3("");
							 }
							 else {
								 textBoxTimer = 250;
								 dialogueID = 2;
							 }
						 }
						 else if (dialogueID == 2 && opponentPokemon1DynamicStats[0] != 0) {
							if (textBoxTimer > 0) {
								textBox.setTextToLoad1("Squirtle used " + opponentPokemonMoveName);
								textBox.setTextToLoad2("");
								textBox.setTextToLoad3("");

							} else {
								textBoxTimer = 250;
								
								if (turnMoveAndDamageHolder[6] == 1) {
									dialogueID = 4;
								}
								else {
									dialogueID = 1;
									damageCalculated = false;
									gameScreen = "MainMenu";
								}
								if (currentPokemonID == 1) {
									if (playerPokemon1DynamicStats[0] - turnMoveAndDamageHolder[2] < 0) {
										playerPokemon1DynamicStats[0] = 0;
									} else {
										playerPokemon1DynamicStats[0] = playerPokemon1DynamicStats[0]
												- turnMoveAndDamageHolder[2];
									}
								} else if (currentPokemonID == 2) {
									if (playerPokemon2DynamicStats[0] - turnMoveAndDamageHolder[2] < 0) {
										playerPokemon2DynamicStats[0] = 0;
									} else {
										playerPokemon2DynamicStats[0] = playerPokemon2DynamicStats[0]
												- turnMoveAndDamageHolder[2];
									}
								}

								
							}
						}
						 
						 else if (dialogueID == 4 && opponentPokemon1DynamicStats[0] != 0) {
							 if (textBoxTimer > 0) {
								 textBox.setTextToLoad1("A Critical Hit");
									textBox.setTextToLoad2("");
									textBox.setTextToLoad3("");
								 }
								 else {
									 textBoxTimer = 250;
									 dialogueID = 1;
									 damageCalculated = false;
									gameScreen = "MainMenu";
								 }
						 }
						 
						 else if (opponentPokemon1DynamicStats[0] == 0) {
							 textBoxTimer = 250;
							 dialogueID = 1;
							 damageCalculated = false;
							gameScreen = "MainMenu";
						 }

					}
				

					else if (itemAppliedOrPokemonSwapped == true) {
						
						if (dialogueID == 1) {
						if (textBoxTimer > 0) {
							textBox.setTextToLoad1("Squirtle used " + opponentPokemonMoveName);
							textBox.setTextToLoad2("");
							textBox.setTextToLoad3("");

						} else {
							textBoxTimer = 250;
							if (turnMoveAndDamageHolder[6] == 1) {
								dialogueID = 2;
							}
							else {
								dialogueID = 1;
								gameScreen = "MainMenu";
								itemAppliedOrPokemonSwapped = false;
								damageCalculated = false;
							}
							
							
							if (currentPokemonID == 1) {
								if (playerPokemon1DynamicStats[0] - turnMoveAndDamageHolder[2] < 0) {
									playerPokemon1DynamicStats[0] = 0;
								} else {
									playerPokemon1DynamicStats[0] = playerPokemon1DynamicStats[0]
											- turnMoveAndDamageHolder[2];
								}
							} else if (currentPokemonID == 2) {
								if (playerPokemon2DynamicStats[0] - turnMoveAndDamageHolder[2] < 0) {
									playerPokemon2DynamicStats[0] = 0;
								} else {
									playerPokemon2DynamicStats[0] = playerPokemon2DynamicStats[0]
											- turnMoveAndDamageHolder[2];
								}
							}

						}
					}
						else if (dialogueID == 2) {
							if (textBoxTimer > 0) {
								textBox.setTextToLoad1("A Critical Hit!");
								textBox.setTextToLoad2("");
								textBox.setTextToLoad3("");

							}
							else {
								itemAppliedOrPokemonSwapped = false;
								damageCalculated = false;
								textBoxTimer = 250;
								gameScreen = "MainMenu";
								dialogueID = 1;
					}
							
					}
					}

					else if (turnMoveAndDamageHolder[0] == 2 && noPP == false) {
						if (dialogueID == 1) {

							if (textBoxTimer > 0) {
								textBox.setTextToLoad1("Squirtle used " + opponentPokemonMoveName);
								textBox.setTextToLoad2("");
								textBox.setTextToLoad3("");

							} else {
								textBoxTimer = 250;
								
								if (turnMoveAndDamageHolder[6] == 1) {
									dialogueID = 3;
								}
								else {
									dialogueID = 2;
								}
								
								
								if (currentPokemonID == 1) {
									if (playerPokemon1DynamicStats[0] - turnMoveAndDamageHolder[2] < 0) {
										playerPokemon1DynamicStats[0] = 0;
									} else {
										playerPokemon1DynamicStats[0] = playerPokemon1DynamicStats[0]
												- turnMoveAndDamageHolder[2];
									}
								} else if (currentPokemonID == 2) {
									if (playerPokemon2DynamicStats[0] - turnMoveAndDamageHolder[2] < 0) {
										playerPokemon2DynamicStats[0] = 0;
									} else {
										playerPokemon2DynamicStats[0] = playerPokemon2DynamicStats[0]
												- turnMoveAndDamageHolder[2];
									}
								}
							}
						}
						
						else if (dialogueID == 3) {
							if (textBoxTimer > 0) {
								textBox.setTextToLoad1("A Critical Hit");
								textBox.setTextToLoad2("");
								textBox.setTextToLoad3("");

							} else {
								textBoxTimer = 250;
								dialogueID = 2;
						}
						}
							
							if (dialogueID == 2 && playerPokemon1DynamicStats[0] != 0  && currentPokemonID == 1 ||dialogueID == 2 && playerPokemon2DynamicStats[0] != 0  && currentPokemonID == 2){

								if (textBoxTimer > 0) {
									if (currentPokemonID == 1 ) {
										textBox.setTextToLoad1("Charmander used " + playerPokemonMoveName);
										textBox.setTextToLoad2("");
										textBox.setTextToLoad3("");
									}
									
									else if (currentPokemonID == 2) {
										textBox.setTextToLoad1("Bulbasaur used" + playerPokemonMoveName);
										textBox.setTextToLoad2("");
										textBox.setTextToLoad3("");
									}
								} else {
									textBoxTimer = 250;
									
									if (turnMoveAndDamageHolder[5] == 1) {
										dialogueID = 4;
									}
									else {
										dialogueID = 1;
										damageCalculated = false;
										gameScreen = "MainMenu";
									}
									
									
									if (opponentPokemon1DynamicStats[0] - turnMoveAndDamageHolder[1] < 0) {
										opponentPokemon1DynamicStats[0] = 0;
									} else {
										opponentPokemon1DynamicStats[0] = opponentPokemon1DynamicStats[0]
												- turnMoveAndDamageHolder[1];
									}
								}
								
							}
							
							else if (dialogueID == 4) {
								if (textBoxTimer > 0) {
									textBox.setTextToLoad1("A Critical Hit!");
									textBox.setTextToLoad2("");
									textBox.setTextToLoad3("");

								} else {
									textBoxTimer = 250;
									dialogueID = 1;
									damageCalculated = false;
									gameScreen = "MainMenu";
							}
							}
							else if (playerPokemon1DynamicStats[0] == 0 || playerPokemon2DynamicStats[0] == 0 ) {
								textBoxTimer = 250;
								dialogueID = 1;
								damageCalculated = false;
								gameScreen = "MainMenu";
							}
							
						
						

					}
					 
					else {
							if (textBoxTimer > 0) {
								textBox.setTextToLoad1("This Move has No PP Left");
								textBox.setTextToLoad2("");
								textBox.setTextToLoad3("");
							}
							else {
								gameScreen = "MainMenu";
								textBoxTimer = 250;
								noPP = false;
								damageCalculated = false;
							}
						}
					
			}
					
					
				
				

				else if (gameScreen == "ItemMechanicsPlayer") {

					textBoxTimer -= 1;

					if (cursor.getLocationY() == 0) {
						if (textBoxTimer > 0) {
							textBox.setTextToLoad1("Can't use pokeball in a trainer battle");
						} else {
							textBoxTimer = 250;
							gameScreen = "MainMenu";
						}

					} else if (cursor.getLocationY() == 1) {
						if (itemAmount[1] != 0) {
							if (dialogueID == 1) {
						
								if (textBoxTimer > 0) {
									textBox.setTextToLoad1("Trainer Used Potion");
									textBox.setTextToLoad2("");
									textBox.setTextToLoad3("");
								} else {
			
									if (currentPokemonID == 1) {
										if (playerPokemon1DynamicStats[0] + 20 > Integer
												.parseInt(playerPokemon1Stats[7])) {
											playerPokemon1DynamicStats[0] = Integer.parseInt(playerPokemon1Stats[7]);
										} else {
											playerPokemon1DynamicStats[0] += 20;
										}
										textBox.setTextToLoad1("Charmander Recovered 20 HP");
										textBox.setTextToLoad2("");
										textBox.setTextToLoad3("");
									} else if (currentPokemonID == 2) {
										if (playerPokemon2DynamicStats[0] + 20 > Integer
												.parseInt(playerPokemon2Stats[7])) {
											playerPokemon2DynamicStats[0] = Integer.parseInt(playerPokemon2Stats[7]);
										} else {
											playerPokemon2DynamicStats[0] += 20;
										}
										textBox.setTextToLoad1("Bulbasaur Recovered 20 HP");
										textBox.setTextToLoad2("");
										textBox.setTextToLoad3("");
									}
									dialogueID = 2;
									textBoxTimer = 250;
								}

							}
							if (dialogueID == 2) {
								if (textBoxTimer > 0) {
									
								} else {
									gameScreen = "BattleMechanics";
									itemAppliedOrPokemonSwapped = true;
									dialogueID = 1;
									textBoxTimer = 250;
									itemAmount[1] = itemAmount[1] - 1;
								}
							}
						} else {
							if (textBoxTimer > 0) {
								textBox.setTextToLoad1("No More Potions Left");
								textBox.setTextToLoad2("");
								textBox.setTextToLoad3("");
							} else {
								gameScreen = "MainMenu";
								dialogueID = 1;
								textBoxTimer = 250;
							}
						}

					} else if (cursor.getLocationY() == 2) {

						gameScreen = "MainMenu";
						dialogueID = 1;
						textBoxTimer = 250;

					}

				}

				else if (gameScreen == "Pokemon") {
					gc.drawImage(pokemonBackground, 0, 161);
					gc.drawImage(partySlotImage, 129, 171);
					gameScreen = cursor.move(gameScreen);

					if (currentPokemonID == 1) {
						partyHUD.display(playerPokemon1Stats, playerPokemon2Stats, playerPokemon1DynamicStats,
								playerPokemon2DynamicStats);
						partyHUD.move(gameScreen, playerPokemon1Stats, playerPokemon2Stats);
					} else if (currentPokemonID == 2) {
						partyHUD.display(playerPokemon2Stats, playerPokemon1Stats, playerPokemon2DynamicStats,
								playerPokemon1DynamicStats);
						partyHUD.move(gameScreen, playerPokemon2Stats, playerPokemon1Stats);
					}

				}

				else if (gameScreen == "PartyIDCheck") {
					if (cursor.getLocationX() == 0 && cursor.getLocationY() == 0) {

						if (playerPokemon1DynamicStats[6] == 1) {
							currentPokemonSummaryID = 1;
						} else if (playerPokemon2DynamicStats[6] == 1) {
							currentPokemonSummaryID = 2;
						}
					} else if (cursor.getLocationX() == 1 && cursor.getLocationY() == 0) {

						if (playerPokemon1DynamicStats[6] == 2) {
							currentPokemonSummaryID = 1;
						} else if (playerPokemon2DynamicStats[6] == 2) {
							currentPokemonSummaryID = 2;
						}

					}

					cursor.setLocationY(0);
					gameScreen = "PartyButtons";
				}

				else if (gameScreen == "PartyButtons") {
					gc.drawImage(pokemonBackground, 0, 161);
					gc.drawImage(partySlotImage, 129, 171);
					if (currentPokemonID == 1) {
						partyHUD.display(playerPokemon1Stats, playerPokemon2Stats, playerPokemon1DynamicStats,
								playerPokemon2DynamicStats);
						partyHUD.move(gameScreen, playerPokemon1Stats, playerPokemon2Stats);
					} else if (currentPokemonID == 2) {
						partyHUD.display(playerPokemon2Stats, playerPokemon1Stats, playerPokemon2DynamicStats,
								playerPokemon1DynamicStats);
						partyHUD.move(gameScreen, playerPokemon2Stats, playerPokemon1Stats);
					}
					gameScreen = cursor.move(gameScreen);
				}

				else if (gameScreen == "Swap") {
					
					
					
					textBoxTimer -= 1;
					
					if (noSwapAllowed == false) {

					if (cursor.getLocationXSwap() == 1 && pokemon2NotFainted == true && playerPokemon2DynamicStats[6] != 1) {

						if (currentPokemonID == 1) {
							if (dialogueID == 1) {
							if (textBoxTimer > 0) {
								System.out.println("yes4");
								textBox.setTextToLoad1("Come Back! Charmander!");	
								gc.drawImage(playerHealthBar, 136, 70);
							} else {
								System.out.println("yes5");
								textBoxTimer = 250;
								dialogueID = 2;
								currentPokemonID = 2;
							}
							}
							
						}
						
						else if (dialogueID == 2) {
							System.out.println("yes9");
							if (textBoxTimer > 0) {
								textBox.setTextToLoad1("Go! Bulbasaur!");
								gc.drawImage(playerHealthBar, 136, 70);
							} else {

								if (playerPokemon1DynamicStats[0] == 0) { 
									
									noSwapAllowed = true;
									gameScreen = "MainMenu";
								}
								else {
									gameScreen = "BattleMechanics";
									itemAppliedOrPokemonSwapped = true;
								}
								System.out.println("yes1");
								textBoxTimer = 250;
								dialogueID = 1;
								playerPokemon1DynamicStats[6] = 2;
								playerPokemon2DynamicStats[6] = 1;
								cursor.setLocationXSwap(0);
								cursor.setLocationX(0);
								cursor.setLocationY(0);
							}
							
						}
						
							
							
							
						} 
						
						
					else if (cursor.getLocationXSwap() == 1) {
						
						if (currentPokemonID == 2) {
							
							if (dialogueID == 1) {
								if (textBoxTimer > 0) {
									textBox.setTextToLoad1("Come Back! Bulbasaur!");	
									gc.drawImage(playerHealthBar, 136, 70);
								} else {
									System.out.println("Yes2");
									textBoxTimer = 250;
									dialogueID = 2;
									currentPokemonID = 1;
								}
								}
							
						}
							
							else if (dialogueID == 2) {
								if (textBoxTimer > 0) {
									textBox.setTextToLoad1("Go! Charmander!");
									gc.drawImage(playerHealthBar, 136, 70);
								} else {
									if (playerPokemon2DynamicStats[0] == 0) { 
										noSwapAllowed = true;
										gameScreen = "MainMenu";
									}
									else {
										gameScreen = "BattleMechanics";
										itemAppliedOrPokemonSwapped = true;
									}
									System.out.println("Yes3");
									textBoxTimer = 250;
									dialogueID = 1;
									
									playerPokemon1DynamicStats[6] = 1;
									playerPokemon2DynamicStats[6] = 2;
									cursor.setLocationXSwap(0);
									cursor.setLocationX(0);
									cursor.setLocationY(0);
								}
							}
								
						
							
						
						
					}
					else {
						if (textBoxTimer > 0) {
							textBox.setTextToLoad1("You Can't swap out a fainted or");
							textBox.setTextToLoad2("Current Pokemon");
						}
						else {
							textBox.setTextToLoad2("");
							System.out.println("Yes6");
							textBoxTimer = 250;
							dialogueID = 1;
							gameScreen = "Pokemon";
							cursor.setLocationX(0);
							cursor.setLocationY(0);
							
						}
						
					}
				
					
					}
					
					else {
						if (textBoxTimer > 0) {
							textBox.setTextToLoad1("You Can't swap out a fainted or");
							textBox.setTextToLoad2("Current Pokemon");
						}
						else {
							textBox.setTextToLoad2("");
							System.out.println("Yes7");
							
							textBoxTimer = 250;
							dialogueID = 1;
							gameScreen = "Pokemon";
							cursor.setLocationX(0);
							cursor.setLocationY(0);
							
						}
					}
					
					
					
					
					
					
					
				
					
				}

				else if (gameScreen == "Summary") {
					gc.drawImage(summaryBackground, 0, 161);
					gameScreen = cursor.move(gameScreen);

					if (currentPokemonSummaryID == 1) {
						summaryHUD.display(cursor, playerPokemon1Stats, playerPokemon1DynamicStats);
						summaryHUD.move(cursor, playerPokemon1Stats);
					} else if (currentPokemonSummaryID == 2) {
						summaryHUD.display(cursor, playerPokemon2Stats, playerPokemon2DynamicStats);
						summaryHUD.move(cursor, playerPokemon2Stats);
					}

				}

				else if (gameScreen == "Bag") {
					gc.drawImage(bagBackground, 0, 161);
					gameScreen = cursor.move(gameScreen);
					itemHUD.display(cursor);
					itemHUD.move(cursor);

				} else if (gameScreen == "Run") {
					
					textBoxTimer -=1;
					
					
					if (textBoxTimer > 0) {
						textBox.setTextToLoad1("Can't Run From A Trainer Battle!");
					}
					else {
						textBoxTimer = 250;
						gameScreen = "MainMenu";
					}

				}
				
				
				
				}
				
				
				
				else {
					endScreenHud.display(gameScreen);
					endScreenHud.move(gameScreen);
					double t = (currentNanoTime - startNanoTime) / 1000000000.0; 
					bike.setX(100);
					bike.setY(241);
					gc.drawImage( bike.getFrame(t), bike.getX(), bike.getY());
					gameScreen = cursor.move(gameScreen);
		
					playerPokemon1DynamicStats[0] = 39;
					playerPokemon1DynamicStats[1] = 10;
					playerPokemon1DynamicStats[2] = 3;
					playerPokemon1DynamicStats[3] = 0;
					playerPokemon1DynamicStats[4] = 0;
					playerPokemon1DynamicStats[5] = 1;
					playerPokemon1DynamicStats[6] = 1;
					playerPokemon2DynamicStats[0] = 45;
					playerPokemon2DynamicStats[1] = 15;
					playerPokemon2DynamicStats[2] = 33;
					playerPokemon2DynamicStats[3] = 0;
					playerPokemon2DynamicStats[4] = 0;
					playerPokemon2DynamicStats[5] = 2;
					playerPokemon2DynamicStats[6] = 2;
					
					opponentPokemon1DynamicStats[0] = 44;
					opponentPokemon1DynamicStats[1] = 15;
					opponentPokemon1DynamicStats[2] = 5;
					opponentPokemon1DynamicStats[3] = 0;
					opponentPokemon1DynamicStats[4] = 0;
					opponentPokemon1DynamicStats[5] = 1;

					mainMenuMusic.play();
					battleMenuMusic.stop();
					
					
					noSwapAllowed = false;
					reset = false;
					
				}
				
				
				
				
				
				
				}
				
				else {
					
			        
					
					endScreenHud.move(gameScreen);
					endScreenHud.display(gameScreen);
					gameScreen =  cursor.move(gameScreen);
					battleMenuMusic.stop();
					if (gameScreen == "StartMenu") {
						gameOver = false;
					}
					
					
				}
				

			}
		}.start();

}

}
