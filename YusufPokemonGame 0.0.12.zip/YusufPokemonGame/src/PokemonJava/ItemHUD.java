package PokemonJava;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;


public class ItemHUD {
	
	
	
	double itemX = 18;
	double itemY = 100 + 161;
	int itemID = 0;
	String itemImageName = "images/ItemPokeball.png";
	Image itemImage = new Image(itemImageName);
	String descriptionsArrayLine1[] = {"A device for catching Wild", "Restores 20 HP to one Pokemon", "Revies a fainted pokemon and"};
	String descriptionsArrayLine2[] = {"Pokemon. It's thrown like a ball,", "", "and restores half of it's", "max HP"};
	String descriptionsArrayLine3[] = {"Confrotably encapsulating its targest", "",""};
	
	//variables -----------------------------------------------
		@FXML
		Canvas gameCanvas;

		GraphicsContext gc;
		
		
		
		

	public ItemHUD(GraphicsContext gc,Canvas gameCanvas) {
			super();
			this.gameCanvas = gameCanvas;
			this.gc = gc;
		}
	
	

		public double getItemX() {
		return itemX;
	}



	public void setItemX(double itemX) {
		this.itemX = itemX;
	}



	public double getItemY() {
		return itemY;
	}



	public void setItemY(double itemY) {
		this.itemY = itemY;
	}



	public int getItemID() {
		return itemID;
	}



	public void setItemID(int itemID) {
		this.itemID = itemID;
	}



	public String getItemImageName() {
		return itemImageName;
	}



	public void setItemImageName(String itemImageName) {
		this.itemImageName = itemImageName;
	}



	public Image getItemImage() {
		return itemImage;
	}



	public void setItemImage(Image itemImage) {
		this.itemImage = itemImage;
	}



	public String[] getDescriptionsArrayLine1() {
		return descriptionsArrayLine1;
	}



	public void setDescriptionsArrayLine1(String[] descriptionsArrayLine1) {
		this.descriptionsArrayLine1 = descriptionsArrayLine1;
	}



	public String[] getDescriptionsArrayLine2() {
		return descriptionsArrayLine2;
	}



	public void setDescriptionsArrayLine2(String[] descriptionsArrayLine2) {
		this.descriptionsArrayLine2 = descriptionsArrayLine2;
	}



	public String[] getDescriptionsArrayLine3() {
		return descriptionsArrayLine3;
	}



	public void setDescriptionsArrayLine3(String[] descriptionsArrayLine3) {
		this.descriptionsArrayLine3 = descriptionsArrayLine3;
	}



	public Canvas getGameCanvas() {
		return gameCanvas;
	}



	public void setGameCanvas(Canvas gameCanvas) {
		this.gameCanvas = gameCanvas;
	}



	public GraphicsContext getGc() {
		return gc;
	}



	public void setGc(GraphicsContext gc) {
		this.gc = gc;
	}



		// displays score and lives on screen
		public void display(Cursor cursor) {
			
			int locationY = cursor.getLocationY();
			
			// draws ScoreStr on screen
			
			if (locationY == 0) {
				itemID = 0;
			}
			else if (locationY == 1) {
				itemID = 1;
			}
			else if (locationY == 2) {
				itemID = 2;
			}
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(descriptionsArrayLine1[itemID], 12, 140 + 161);
			gc.setFill(Color.BLACK);
			gc.fillText(descriptionsArrayLine2[itemID], 12, 162 + 161);
			gc.setFill(Color.BLACK);
			gc.fillText(descriptionsArrayLine3[itemID], 12, 184 + 161);
		}
		
		public void move(Cursor cursor) {
			
			int locationY = cursor.getLocationY();
			
			if (locationY == 0) {
				itemImageName = "images/ItemPokeball.png";
			}
			else if (locationY == 1) {
				itemImageName = "images/ItemPotion.png";
			}
			else if (locationY == 2) {
				itemImageName = "images/ItemRevive.png";
			}
			
			this.itemImage = new Image(this.itemImageName);
			this.gc.drawImage(this.itemImage, this.itemX, this.itemY); // draws the image on screen
			
		}
	
	
	

}
