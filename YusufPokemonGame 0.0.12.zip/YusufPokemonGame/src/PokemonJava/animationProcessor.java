package PokemonJava;

import javafx.scene.image.Image;

public class animationProcessor {
	
	public Image[] frames;
	public double duration;

	double x;
	double y;

	public Image getFrame(double time) {
		int index = (int) ((time % (frames.length * duration)) / duration);
		return frames[index];
	}


	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
}
