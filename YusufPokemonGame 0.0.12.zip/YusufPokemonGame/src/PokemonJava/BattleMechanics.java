package PokemonJava;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

public class BattleMechanics {
	
	//variables -----------------------------------------------
	@FXML
	Canvas gameCanvas;

	GraphicsContext gc;

	public BattleMechanics(GraphicsContext gc, Canvas gameCanvas) {
		super();
		this.gameCanvas = gameCanvas;
		this.gc = gc;
	}
	
	public int[] fightMechanics(Cursor cursor,String[] playerPokemonStats, String[] opponentPokemonStats, boolean itemApplied) {
		
		
		// player Move 
		
		double playerPokemonDamageGiven = 0;
		double opponentPokemonDamageGiven = 0;
		double playerPokemonModifier = 1;
		double opponentPokemonModifier = 1;
		
	int TurnAndDamageHolder[] = new int[7];
		
		
		String playerPokemonType = playerPokemonStats[0];
		double playerPokemonLevel = Double.parseDouble(playerPokemonStats[5]);
		double playerPokemonAttackStat =  Double.parseDouble(playerPokemonStats[8]);
		double playerPokemonDefenseStat =  Double.parseDouble(playerPokemonStats[9]);
		double playerPokemonSpecialAttackStat =  Double.parseDouble(playerPokemonStats[10]);
		double playerPokemonSpecialDefenseStat =  Double.parseDouble(playerPokemonStats[11]);
		String playerPokemonMoveType = "";
		String playerPokemonMovePhysicalOrSpecial = "";
		double playerPokemonMovePower = 40;
		
		
		
		if (itemApplied == false) {
		
		
		if (cursor.getLocationX() == 0 && cursor.getLocationY() == 0) {
			
			playerPokemonMoveType = playerPokemonStats[39];
			playerPokemonMovePhysicalOrSpecial = playerPokemonStats[43];
			playerPokemonMovePower = Double.parseDouble(playerPokemonStats[15]);
			TurnAndDamageHolder[3] = 1;


		}
		
		else if (cursor.getLocationX() == 1 && cursor.getLocationY() == 0) {
			
			playerPokemonMoveType = playerPokemonStats[40];
			playerPokemonMovePhysicalOrSpecial = playerPokemonStats[44];
			playerPokemonMovePower = Double.parseDouble(playerPokemonStats[20]);
			TurnAndDamageHolder[3] = 2;

		}
		
		else if (cursor.getLocationX() == 0 && cursor.getLocationY() == 1) {
			
			playerPokemonMoveType = playerPokemonStats[41];
			playerPokemonMovePhysicalOrSpecial = playerPokemonStats[45];
			playerPokemonMovePower = Double.parseDouble(playerPokemonStats[25]);
			TurnAndDamageHolder[3] = 3;
		}
		
		else if (cursor.getLocationX() == 1 && cursor.getLocationY() == 1) {
			
			playerPokemonMoveType = playerPokemonStats[42];
			playerPokemonMovePhysicalOrSpecial = playerPokemonStats[46];
			playerPokemonMovePower = Double.parseDouble(playerPokemonStats[30]);
			TurnAndDamageHolder[3] = 4;
		}
		
		}
		
		String opponentPokemonType  = opponentPokemonStats[1];
		double opponentPokemonLevel = Double.parseDouble(opponentPokemonStats[5]);
		double opponentPokemonAttackStat = Double.parseDouble(opponentPokemonStats[7]);
		double opponentPokemonDefenseStat = Double.parseDouble(opponentPokemonStats[8]);
		double opponentPokemonSpecialAttackStat = Double.parseDouble(opponentPokemonStats[9]);
		double opponentPokemonSpecialDefenseStat = Double.parseDouble(opponentPokemonStats[10]);
		String opponentPokemonMoveType = "";
		String opponentPokemonMovePhysicalOrSpecial = "";
		double opponentPokemonMovePower = 40;
		
		
		
		
		double opponentPokemonNumberOfMoves = 2; //hardcoded 
		int opponentPokemonMoveSelected =  2; // random wont work
		
		if (opponentPokemonMoveSelected == 1) {
			opponentPokemonMoveType = opponentPokemonStats[13] ;
			opponentPokemonMovePhysicalOrSpecial = opponentPokemonStats[32] ;
			opponentPokemonMovePower = Double.parseDouble(opponentPokemonStats[14]);
			TurnAndDamageHolder[4] = 1;
			
		}
		else if (opponentPokemonMoveSelected == 2) {
			
			opponentPokemonMoveType = opponentPokemonStats[18] ;
			opponentPokemonMovePhysicalOrSpecial = opponentPokemonStats[33] ;
			opponentPokemonMovePower = Double.parseDouble(opponentPokemonStats[19]);
			TurnAndDamageHolder[4] = 2;
		}
		else if (opponentPokemonMoveSelected == 3) {
			opponentPokemonMoveType = opponentPokemonStats[5];
			opponentPokemonMovePhysicalOrSpecial = opponentPokemonStats[34] ;
			opponentPokemonMovePower = Double.parseDouble(opponentPokemonStats[24]);
			TurnAndDamageHolder[4] = 3;
			
		} 
		else if (opponentPokemonMoveSelected == 4) {
			opponentPokemonMoveType = opponentPokemonStats[28] ;
			opponentPokemonMovePhysicalOrSpecial = opponentPokemonStats[35];
			opponentPokemonMovePower = Double.parseDouble(opponentPokemonStats[29]);
			TurnAndDamageHolder[4] = 4;
		}
		
		
		
		
		
		
		//ModifierCode
		
		double playerPokemonSpeed = Double.parseDouble(playerPokemonStats[12]);
		double playerPokemonCriticalRandom = (Math.random() * 256) + 1;
		double playerPokemonCriticalHitThreshold = playerPokemonSpeed / 2;
		double playerPokemonCriticalHit = 1;
		double playerPokemonSTAB = 1;
		double playerPokemonTypeEffectiveness = 1;
		double playerPokemonRandom = (Math.random() * 0.15) + 0.85;
		
		
		double opponentPokemonSpeed = Double.parseDouble(opponentPokemonStats[11]);
		double opponentPokemonCriticalRandom = (Math.random() * 256) + 1;
		double opponentPokemonCriticalHitThreshold = opponentPokemonSpeed / 2;
		double opponentPokemonCriticalHit = 1;
		double opponentPokemonSTAB = 1;
		double opponentPokemonTypeEffectiveness = 1;
		double opponentPokemonRandom = (Math.random() * 0.15) + 0.85;
		
		
		// Critcial Hit 
		
		if (itemApplied == false) {
		
		if (playerPokemonCriticalRandom < playerPokemonCriticalHitThreshold) {
			playerPokemonCriticalHit = 2;
			TurnAndDamageHolder[5] = 1;
		}
		else {
			playerPokemonCriticalHit = 1;
			TurnAndDamageHolder[5] = 0;
		}
		
		
		
		//STAB
		if (playerPokemonType.equals(playerPokemonMoveType)) {
			playerPokemonSTAB = 1.5;
		}
		else {
			playerPokemonSTAB = 1;
		}
		
		//TypeEFFECTIVENESS 
		
		if (playerPokemonMoveType == "Fire" && opponentPokemonType == "Water") {
			playerPokemonTypeEffectiveness = 0.5;
		}
		else if (playerPokemonMoveType == "Grass" && opponentPokemonType == "Water") {
			playerPokemonTypeEffectiveness = 2;
		}
		else {
			playerPokemonTypeEffectiveness = 1;
		}
		
		
		
		}
		
	
		
		
		// Opponent Critical Hit
		
		if (opponentPokemonCriticalRandom < opponentPokemonCriticalHitThreshold) {
			opponentPokemonCriticalHit = 2;
			TurnAndDamageHolder[6] = 1;
		}
		else {
			opponentPokemonCriticalHit = 1;
			TurnAndDamageHolder[6] = 0;
		}
		
		
		// Opponent STAB
		
		if (opponentPokemonType.equals(opponentPokemonMoveType)) {
			opponentPokemonSTAB = 1.5;
		}
		else {
			opponentPokemonSTAB = 1;
		}
		
		// Opponent Type Effectiveness
		
		if (opponentPokemonMoveType == "Water" && playerPokemonType == "Fire") {
			opponentPokemonTypeEffectiveness = 2;
		}
		
		else if (opponentPokemonMoveType == "Water" && playerPokemonType == "Grass") {
			opponentPokemonTypeEffectiveness = 0.5;
		}
		else {
			opponentPokemonTypeEffectiveness = 1;
		}
		
		
		
		
		//playerModifier
		if (itemApplied == false) {
		playerPokemonModifier = playerPokemonCriticalHit*playerPokemonSTAB*playerPokemonTypeEffectiveness*playerPokemonRandom;
		}
		
		
		// OpponentModifier
		
		
		opponentPokemonModifier = opponentPokemonCriticalHit*opponentPokemonSTAB*opponentPokemonTypeEffectiveness*opponentPokemonRandom;
		
		// First goes calculator
		
		if (Double.parseDouble(playerPokemonStats[12]) > Double.parseDouble(opponentPokemonStats[11])) {
			TurnAndDamageHolder[0] = 1;	
		}
		else {
			TurnAndDamageHolder[0] = 2;
		}
		
		if (itemApplied == false) {
		if (playerPokemonMovePhysicalOrSpecial == "Physical") {
			playerPokemonDamageGiven = ((2*playerPokemonLevel/5+2)*playerPokemonMovePower*playerPokemonAttackStat/opponentPokemonDefenseStat/50+2)*playerPokemonModifier;
			}
		else if (playerPokemonMovePhysicalOrSpecial == "Special"){
				playerPokemonDamageGiven = ((2*playerPokemonLevel/5+2)*playerPokemonMovePower*playerPokemonSpecialAttackStat/opponentPokemonSpecialDefenseStat/50+2)*playerPokemonModifier;
				}
		}
		
		
		if (opponentPokemonMovePhysicalOrSpecial == "Physical") {
			opponentPokemonDamageGiven = ((2*opponentPokemonLevel/5+2)*opponentPokemonMovePower*opponentPokemonAttackStat/playerPokemonDefenseStat/50+2)*opponentPokemonModifier;
			}
		else if (opponentPokemonMovePhysicalOrSpecial == "Special"){
				opponentPokemonDamageGiven = ((2*opponentPokemonLevel/5+2)*opponentPokemonMovePower*opponentPokemonSpecialAttackStat/playerPokemonSpecialDefenseStat/50+2)*opponentPokemonModifier;
				}
		
		
		//TurnAndDamageHolder[1] = (int) playerPokemonDamageGiven;
		TurnAndDamageHolder[1] = 50;
		TurnAndDamageHolder[2] = (int) opponentPokemonDamageGiven;

		
		
		if (itemApplied == false) {
		System.out.println("player Pokemon Type: " + playerPokemonType);
		System.out.println("player Pokemon Level: " + playerPokemonLevel);
		System.out.println("player Pokemon Attack: " + playerPokemonAttackStat);
		System.out.println("player Pokemon Defense: " + playerPokemonDefenseStat);
		System.out.println("player Pokemon SP.Atk: " + playerPokemonSpecialAttackStat);
		System.out.println("player Pokemon SP.Def: " + playerPokemonSpecialDefenseStat);
		System.out.println("player Pokemon Move Type: " + playerPokemonMoveType);
		System.out.println("player Pokemon Physical Or Special Move: " + playerPokemonMovePhysicalOrSpecial);
		System.out.println("player Pokemon Speed: " + playerPokemonSpeed);
		System.out.println("player Pokemon Move Power: " + playerPokemonMovePower);
		System.out.println("player Pokemon CriticalRandom: " + playerPokemonCriticalRandom);
		System.out.println("player Pokemon Critical Hit Threshold: " + playerPokemonCriticalHitThreshold);
		System.out.println("player Pokemon Critical Hit: " + playerPokemonCriticalHit);
		System.out.println("player Pokemon STAB: " + playerPokemonSTAB);
		System.out.println("player Pokemon TypeEffectiveness: " + playerPokemonTypeEffectiveness);
		System.out.println("player Pokemon Modifier: " + playerPokemonModifier);
		System.out.println("player Pokemon Damage Given: " + playerPokemonDamageGiven);
		}
		System.out.println("opponent Pokemon Type: " + opponentPokemonType);
		System.out.println("opponent Pokemon Level: " + opponentPokemonLevel);
		System.out.println("opponent Pokemon Attack: " + opponentPokemonAttackStat);
		System.out.println("opponent Pokemon Defense: " + opponentPokemonDefenseStat);
		System.out.println("opponent Pokemon SP.Atk: " + opponentPokemonSpecialAttackStat);
		System.out.println("opponent Pokemon SP.Def: " + opponentPokemonSpecialDefenseStat);
		System.out.println("opponent Pokemon Move Type: " + opponentPokemonMoveType);
		System.out.println("opponent Pokemon Physical Or Special Move: " + opponentPokemonMovePhysicalOrSpecial);
		System.out.println("opponent Pokemon Speed: " + opponentPokemonSpeed);
		System.out.println("opponent Pokemon Move Power: " + opponentPokemonMovePower);
		System.out.println("opponent Pokemon CriticalRandom: " + opponentPokemonCriticalRandom);
		System.out.println("opponent Pokemon Critical Hit Threshold: " + opponentPokemonCriticalHitThreshold);
		System.out.println("opponent Pokemon Critical Hit: " + opponentPokemonCriticalHit);
		System.out.println("opponent Pokemon STAB: " + opponentPokemonSTAB);
		System.out.println("opponent Pokemon TypeEffectiveness: " + opponentPokemonTypeEffectiveness);
		System.out.println("opponent Pokemon Modifier: " + opponentPokemonModifier);
		System.out.println("opponent Pokemon Damage Given: " + opponentPokemonDamageGiven);
		System.out.println("Goes First:" + TurnAndDamageHolder[0]);
		
		
	
		
		
		return TurnAndDamageHolder;
		
	}
	
}

