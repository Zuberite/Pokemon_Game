package PokemonJava;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class FightHUD {
	
	//variables -----------------------------------------------
			@FXML
			Canvas gameCanvas;

			GraphicsContext gc;
	
	double move1X = 1;
	double move1Y = 185;
	String move1ImageName = "images/MoveTypeNull.png";
	Image move1Image = new Image(move1ImageName);
	
	double move2X = 129;
	double move2Y = 185;
	String move2ImageName = "images/MoveTypeNull.png";
	Image move2Image = new Image(move2ImageName);
	
	double move3X = 1;
	double move3Y = 248;
	String move3ImageName = "images/MoveTypeNull.png";
	Image move3Image = new Image(move3ImageName);
	
	double move4X = 129;
	double move4Y = 248;
	String move4ImageName = "images/MoveTypeNull.png";
	Image move4Image = new Image(move4ImageName);
	
	
	public FightHUD(GraphicsContext gc, Canvas gameCanvas) {
		super();
		this.gameCanvas = gameCanvas;
		this.gc = gc;
	}
	
	public void display(String[] playerPokemonStats, int[] playerPokemonDynamicStats) {
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[13], 20, 45 + 161);
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[18], 140, 45 + 161);
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[23], 20, 100 + 161);
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[28], 140, 100 + 161);
		
		
		
		if (playerPokemonDynamicStats[1] != 0) {
		gc.setFill(Color.BLACK);
		gc.fillText(Integer.toString(playerPokemonDynamicStats[1]), 75, 65 + 161);
		}
		if (playerPokemonDynamicStats[2] != 0) {
		gc.setFill(Color.BLACK);
		gc.fillText(Integer.toString(playerPokemonDynamicStats[2]), 208, 65 + 161);
		}
		if (playerPokemonDynamicStats[3] != 0) {
		gc.setFill(Color.BLACK);
		gc.fillText(Integer.toString(playerPokemonDynamicStats[3]), 80, 130 + 161);
		}
		if (playerPokemonDynamicStats[4] != 0) {
		gc.setFill(Color.BLACK);
		gc.fillText(Integer.toString(playerPokemonDynamicStats[4]), 195, 130 + 161);
		}
		
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[17], 95, 65 + 161);
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[22], 222, 65 + 161);
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[27], 90, 130 + 161);
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[32], 205, 130 + 161);
	
	}
	
	public void move(String[] playerPokemonStats) {
		
		this.move1ImageName = playerPokemonStats[14];
		this.move2ImageName = playerPokemonStats[19];
		this.move3ImageName = playerPokemonStats[24];
		this.move4ImageName = playerPokemonStats[29];
		
		this.move1Image = new Image(this.move1ImageName);
		this.move2Image = new Image(this.move2ImageName);
		this.move3Image = new Image(this.move3ImageName);
		this.move4Image = new Image(this.move4ImageName);
		
		this.gc.drawImage(this.move1Image, this.move1X, this.move1Y);
		this.gc.drawImage(this.move2Image, this.move2X, this.move2Y);
		this.gc.drawImage(this.move3Image, this.move3X, this.move3Y);
		this.gc.drawImage(this.move4Image, this.move4X, this.move4Y);
	}

	
	
}
