package PokemonJava;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class PartyHUD {
	
	
	
		
	
	//variables -----------------------------------------------
			
	double x = 200;
	double y = 161 + 112;
	double pokemon1X = 5;
	double pokemon1Y = 165;
	String pokemon1ImageName = "images/PartyCharmander.png";
	Image pokemon1Image = new Image(pokemon1ImageName);
	double pokemon2X = 133;
	double pokemon2Y = 172;
	String pokemon2ImageName = "images/PartyBulbasaur.png";
	Image pokemon2Image = new Image(pokemon2ImageName);
	
	String imageName = "images/PartySummaryAndSwitchButton.png";
	Image image = new Image(imageName);	
	
	
			@FXML
			Canvas gameCanvas;

			GraphicsContext gc;
			
			
		
	
	
	public PartyHUD(GraphicsContext gc, Canvas gameCanvas) {
				super();
				this.gameCanvas = gameCanvas;
				this.gc = gc;
			}





	public void display (String[] playerPokemon1Stats, String[] playerPokemon2Stats, int[] playerPokemon1DyanmicStats, int[] playerPokemon2DyanmicStats) {
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.WHITE);
		gc.fillText(playerPokemon1Stats[0], 37, 161 + 20);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.WHITE);
		gc.fillText(playerPokemon1Stats[5], 23, 161 + 42);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.WHITE);
		gc.fillText(playerPokemon1Stats[7], 72, 161 + 42);
		
		String playerPokemon1DyanamicStatsString = Integer.toString(playerPokemon1DyanmicStats[0]);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.WHITE);
		gc.fillText(playerPokemon1DyanamicStatsString, 94, 161 + 42);
		
		
		
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.WHITE);
		gc.fillText(playerPokemon2Stats[0], 164, 161 + 26);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.WHITE);
		gc.fillText(playerPokemon2Stats[5], 151, 161 + 50);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.WHITE);
		gc.fillText(playerPokemon2Stats[7], 200, 161 + 50);
		
		String playerPokemon2DyanamicStatsString = Integer.toString(playerPokemon2DyanmicStats[0]);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.WHITE);
		gc.fillText(playerPokemon2DyanamicStatsString, 222, 161 + 50);
		
		
	}
	
	
	public void move(String gameScreen, String[] playerPokemon1Stats,String[] playerPokemon2Stats) {
			
		if (gameScreen == "PartyButtons") {
			this.gc.drawImage(this.image, this.x, this.y); 
		}
		
		this.pokemon1ImageName = playerPokemon1Stats[37];
		this.pokemon2ImageName = playerPokemon2Stats[37];
		
		this.pokemon1Image = new Image(pokemon1ImageName);
		this.pokemon2Image = new Image(pokemon2ImageName);
		
		
		this.gc.drawImage(this.pokemon1Image, this.pokemon1X, this.pokemon1Y); 
		this.gc.drawImage(this.pokemon2Image, this.pokemon2X, this.pokemon2Y); 
		
		
		
	}
	
	
}
