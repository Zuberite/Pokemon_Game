package PokemonJava;

public class soundLoader {

}
