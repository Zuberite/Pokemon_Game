package PokemonJava;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.image.Image;

public class endScreenHud {
	
	
	
	//variables -----------------------------------------------
	@FXML
	Canvas gameCanvas;

	GraphicsContext gc;
	
	
	double pokemonLogoX = 0;
	double pokemonLogoY = 120;
	String pokemonLogoImageName = "images/PokemonLogo.png";
	Image pokemonLogoImage = new Image(pokemonLogoImageName);
	double startScreenBackgroundX = 0;
	double startScreenBackgroundY= 0;
	String startScreenBackgroundImageName = "images/StartScreen.png";
	Image startScreenBackgroundImage = new Image(startScreenBackgroundImageName);
	
	
	public endScreenHud(GraphicsContext gc, Canvas gameCanvas) {
		super();
		this.gameCanvas = gameCanvas;
		this.gc = gc;
	}
	
	
	
	public void display(String gameScreen) {
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		
		if (gameScreen == "StartMenu") {
			gc.setFill(Color.BLACK);
			gc.fillText("Press 'A' to Start the game", 20, 340);
			gc.fillText("Made by Subbayal Yusuf", 20, 352);
		
	}
		else {
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 18));
			gc.setFill(Color.BLACK);
			gc.fillText("Thanks For Playing", 20, 161 );
			gc.fillText("Made By Subbayal Yusuf", 20, 181 );
			gc.fillText("Based off Pokemon", 20, 201 );
			gc.fillText("Gen 3 and Gen 1", 20, 221 );
			gc.fillText("Full Game Release:", 20, 241 );
			gc.fillText("Feburary 2099 :)", 20, 261 );
			gc.fillText("Press 'A' to play again", 20, 330);
		}
	}
	
	public void move (String gameScreen) {
		
		
		if (gameScreen == "StartMenu") {
			this.gc.drawImage(this.startScreenBackgroundImage, this.startScreenBackgroundX, this.startScreenBackgroundY);
			this.gc.drawImage(this.pokemonLogoImage, this.pokemonLogoX, this.pokemonLogoY);
			
			
		}
		else {
			this.gc.drawImage(this.startScreenBackgroundImage, this.startScreenBackgroundX, this.startScreenBackgroundY);
		}
	}
	
}
