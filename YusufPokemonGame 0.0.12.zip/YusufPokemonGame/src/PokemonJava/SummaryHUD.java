package PokemonJava;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class SummaryHUD {
	
	double pokemonX = 30;
	double pokemonY = 161 + 85;
	double move1X = 129;
	double move1Y = 161 + 35;
	double move2X = 129;
	double move2Y = 161 + 67;
	double move3X = 129;
	double move3Y = 161 + 99;
	double move4X = 129;
	double move4Y = 161 + 131;
	String pokemonImageName = "images/CharmanderFront.png";
	String move1ImageName = "images/SummaryMoveNormal.png";
	String move2ImageName = "images/SummaryMoveNormal.png";
	String move3ImageName = "images/SummaryMoveNormal.png";
	String move4ImageName = "images/SummaryMoveNormal.png";
	Image pokemonImage = new Image(pokemonImageName);
	Image move1Image = new Image(move1ImageName);
	Image move2Image = new Image(move2ImageName);
	Image move3Image = new Image(move3ImageName);
	Image move4Image = new Image(move4ImageName);
	
	@FXML
	Canvas gameCanvas;

	GraphicsContext gc;

	public SummaryHUD(GraphicsContext gc, Canvas gameCanvas) {
		super();
		this.gameCanvas = gameCanvas;
		this.gc = gc;
	}
	
	public void display (Cursor cursor, String playerPokemonStats[], int playerPokemonDynamicStats[]) {
		
		
		int locationX = cursor.getLocationX();
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[0], 23, 161 + 35);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[5], 23, 161 + 52);
		
		if (locationX == 0) {
		
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(Integer.toString(playerPokemonDynamicStats[0]), 190, 161 + 45);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[7], 210, 161 + 45);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[8], 200, 161 + 69);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[9], 200, 161 + 85);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[10], 200, 161 + 101);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[11], 200, 161 + 117);
		
		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
		gc.setFill(Color.BLACK);
		gc.fillText(playerPokemonStats[12], 200, 161 + 133);
		
		
			
	}
		
		if (locationX == 1) {
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[5], 180, 161 + 53);
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[0], 180, 161 + 69);
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[1], 180, 161 + 85);
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[6], 180, 161 + 101);
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText("777777", 180, 161 + 117);
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText("9000", 180, 161 + 149);
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText("???", 180, 161 + 181);
				
		}
		
		if (locationX == 2) {
			
			
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[13], 170, 161 + 45);
			
			if (playerPokemonDynamicStats[1] != 0) {
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(Integer.toString(playerPokemonDynamicStats[1]), 225, 161 + 61);
			}
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[17], 205, 161 + 61);
			
			
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[18], 170, 161 + 77);
			
			if (playerPokemonDynamicStats[2] != 0) {
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(Integer.toString(playerPokemonDynamicStats[2]), 225, 161 + 93);
			}
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[22], 205, 161 + 93);
			
			
			
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[23], 170, 161 + 109);
			
			if (playerPokemonDynamicStats[3] != 0) {
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(Integer.toString(playerPokemonDynamicStats[3]), 225, 161 + 125);
			}
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[27], 205, 161 + 125);
			
			
		
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[28], 170, 161 + 141);
			
			if (playerPokemonDynamicStats[4] != 0) {
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(Integer.toString(playerPokemonDynamicStats[4]), 225, 161 + 157);
			}
			gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			gc.setFill(Color.BLACK);
			gc.fillText(playerPokemonStats[32], 205, 161 + 157);
			
			
				
		}
	
	

}
	
	public void move (Cursor cursor, String playerPokemonStats[]) {
		
		
		this.pokemonImageName = playerPokemonStats[38];
		this.pokemonImage = new Image(pokemonImageName);
		
		
		int locationX = cursor.getLocationX();
		
		if (playerPokemonStats[33] != "") {
		this.move1X = 129;
		this.move1Y = 161 + 35;
		this.move1ImageName = playerPokemonStats[33];
		}
		else {
			this.move1X = 1000;
			this.move1Y = 1000;
		}
		if (playerPokemonStats[34] != "") {
		this.move2X = 129;
		this.move2Y = 161 + 67;
		this.move2ImageName = playerPokemonStats[34];
		}
		else {
			this.move2X = 1000;
			this.move2Y = 1000;
		}
		if (playerPokemonStats[35] != "") {
			this.move3X = 129;
			this.move3Y = 161 + 99;
		this.move3ImageName = playerPokemonStats[35];
		}
		else {
			this.move3X = 1000;
			this.move3Y = 1000;
		}
		
			
		
		if (playerPokemonStats[36] != "") {
		this.move4X = 129;
		this.move4Y = 161 + 131;
		this.move4ImageName = playerPokemonStats[36];
		}
		else {
			this.move4X = 1000;
			this.move4Y = 1000;
		}
		
		
		
		this.move1Image = new Image(this.move1ImageName);
		this.move2Image = new Image(this.move2ImageName);
		this.move3Image = new Image(this.move3ImageName);
		this.move4Image = new Image(this.move4ImageName);
		
		this.gc.drawImage(this.pokemonImage, this.pokemonX, this.pokemonY);
		if (locationX == 2) {
		this.gc.drawImage(this.move1Image, this.move1X, this.move1Y);
		this.gc.drawImage(this.move2Image, this.move2X, this.move2Y);
		this.gc.drawImage(this.move3Image, this.move3X, this.move3Y);
		this.gc.drawImage(this.move4Image, this.move4X, this.move4Y);
		}
		
	}
	
}
