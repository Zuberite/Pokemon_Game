package PokemonJava;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class Cursor {

	// variables -----------------------------------------------
	String left = "LEFT";
	String right = "RIGHT";
	String up = "UP";
	String down = "DOWN";
	String a = "A";
	double x = 0;
	double y = 0;
	int locationX = 0;
	int locationY = 0;
	int locationXSwap = 0;
	int inputTimer = 7;
	String menu = "mainMenu";
	String imageName = "images/BigMenuCursor.png";
	Image image = new Image(imageName);
	GraphicsContext gc;
	@FXML
	Canvas gameCanvas;
	ArrayList<String> input; // for cursor input

	// constructors -----------------------------------------------

	public String getLeft() {
		return left;
	}

	public Cursor(GraphicsContext gc, Canvas gameCanvas, ArrayList<String> input) {
		super();
		this.gc = gc;
		this.gameCanvas = gameCanvas;
		this.input = input;
	}

	public String getRight() {
		return right;
	}

	public void setRight(String right) {
		this.right = right;
	}

	public String getUp() {
		return up;
	}

	public void setUp(String up) {
		this.up = up;
	}

	public String getDown() {
		return down;
	}

	public void setDown(String down) {
		this.down = down;
	}

	public String getA() {
		return a;
	}

	public void setA(String a) {
		this.a = a;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public int getLocationX() {
		return locationX;
	}

	public void setLocationX(int locationX) {
		this.locationX = locationX;
	}

	public int getLocationY() {
		return locationY;
	}

	public void setLocationY(int locationY) {
		this.locationY = locationY;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public GraphicsContext getGc() {
		return gc;
	}

	public void setGc(GraphicsContext gc) {
		this.gc = gc;
	}

	public Canvas getGameCanvas() {
		return gameCanvas;
	}

	public void setGameCanvas(Canvas gameCanvas) {
		this.gameCanvas = gameCanvas;
	}

	public ArrayList<String> getInput() {
		return input;
	}

	public void setInput(ArrayList<String> input) {
		this.input = input;
	}

	public void setLeft(String left) {
		this.left = left;
	}
	
	

	public int getLocationXSwap() {
		return locationXSwap;
	}

	public void setLocationXSwap(int locationXSwap) {
		this.locationXSwap = locationXSwap;
	}

	// contains all code to move and display image -----------------
	public String move(String gameScreen) {
		
		if (this.inputTimer > 0 ) {
			
			this.inputTimer -= 1;
		}
		
		
			
		

		// for left button pressed
		if (this.inputTimer == 0) {
			
		
		if (this.input.contains(this.left)) {

			this.locationX -= 1;
			this.inputTimer = 7;

			// for right button pressed
		} else if (this.input.contains(this.right)) {

			this.locationX += 1;
			this.inputTimer = 7;

			// if neither are pressed
		} 
		// for up button pressed
		if (this.input.contains(this.up)) {

			this.locationY -= 1;
			this.inputTimer = 7;

			// for down button pressed
		} else if (this.input.contains(this.down)) {

			this.locationY += 1;
			this.inputTimer = 7;

			// if neither are pressed
		}
		
		}
		
		if (gameScreen == "StartMenu") {
			this.x = 1000;
			this.y = 1000;
			if (this.inputTimer == 0) {
			if (this.input.contains(this.a)) {
				inputTimer = 7;
				gameScreen = "MainMenu";
				locationX = 0;
				locationY = 0;
			}
			}
			
		}
		
		else if (gameScreen == "EndMenu") {
			
			this.x = 1000;
			this.y = 1000;
			if (this.inputTimer == 0) {
			if (this.input.contains(this.a)) {
				inputTimer = 7;
				gameScreen = "StartMenu";
			}
			}
		}

		else if (gameScreen == "MainMenu") {

			if (locationX > 2) {
				this.locationX = 2;
			}

			else if (locationX < 0) {
				this.locationX = 0;
			}

			if (locationY > 1) {
				this.locationY = 1;
			}

			else if (locationY < 0) {
				this.locationY = 0;
			}

			if (locationY == 0) {
				this.x = 19;
				this.y = 197;
				this.imageName = "images/BigMenuCursor.png";
			} else if (locationX == 2 && locationY == 1) {
				this.x = 176;
				this.y = 311;
				this.imageName = "images/MenuCursor.png";
			} else if (locationX == 1 && locationY == 1) {
				this.x = 88;
				this.y = 315;
				this.imageName = "images/MenuCursor.png";
			} else if (locationX == 0 && locationY == 1) {
				this.x = 0;
				this.y = 311;
				this.imageName = "images/MenuCursor.png";
			}

			if (this.inputTimer == 0) {
			if (this.input.contains(this.a)) {
			
				if (locationX == 0 && locationY == 0) {
					gameScreen = "Fight";
					locationX = 0;
					locationY = 0;
					this.inputTimer = 30;
				} else if (locationX == 2 && locationY == 1) {
					gameScreen = "Pokemon";
					this.inputTimer = 7;
				} else if (locationX == 1 && locationY == 1) {
					gameScreen = "Run";
					this.inputTimer = 7;
				} else if (locationX == 0 && locationY == 1) {
					gameScreen = "Bag";
					this.inputTimer = 7;
				} 
				
				locationX = 0;
				locationY = 0;
				
				

			}
			} 

		}

		else if (gameScreen == "Fight") {
			

			if (locationX > 1) {
				this.locationX = 1;
			}

			else if (locationX < 0) {
				this.locationX = 0;
			}

			if (locationY > 1) {
				this.locationY = 1;
			}

			else if (locationY < 0) {
				this.locationY = 0;
			}

			if (locationX == 0 && locationY == 0) {
				this.x = 1;
				this.y = 185;
				this.imageName = "images/FightCursor.png";
			} else if (locationX == 1 && locationY == 0) {
				this.x = 129;
				this.y = 185;
				this.imageName = "images/FightCursor.png";
			}
			else if (locationY == 1) {
				this.x = 9;
				this.y = 319;
				this.imageName = "images/FightExitCursor.png";
			}
			
			if (this.input.contains(this.a)) {
					
				if (this.inputTimer == 0 ) {
				if (locationX == 0 && locationY == 0) {
					gameScreen = "BattleMechanics";
					this.inputTimer = 7;
					
				} else if (locationX == 1 && locationY == 0) {
					gameScreen = "BattleMechanics";
					this.inputTimer = 7;
				
				} else if  (locationY == 1) {
					gameScreen = "MainMenu";
					System.out.print("Yes");
					this.imageName = "images/BigMenuCursor.png";
					locationX = 1;
					locationY = 1;	
					this.inputTimer = 7;
				}
				}
				
				
			}
			
			

		}

		else if (gameScreen == "Pokemon") {

			if (locationX > 1) {
				this.locationX = 1;
			}

			else if (locationX < 0) {
				this.locationX = 0;
			}

			if (locationY > 1) {
				this.locationY = 1;
			}

			else if (locationY < 0) {
				this.locationY = 0;
			}

			if (locationX == 0 && locationY == 0) {
				this.x = 1;
				this.y = 162;
				this.imageName = "images/PartyStarterCursor.png";
			} else if (locationX == 1 && locationY == 0) {
				this.x = 129;
				this.y = 169;
				this.imageName = "images/PartyCursor.png";
			}
			else if ( locationY == 1) {
				this.x = 200;
				this.y = 161 + 164;
				this.imageName = "images/PartyCancelCursor.png";
			}
			
			if (this.inputTimer == 0) {
				if (this.input.contains(this.a)) {
				
					if (locationY == 1) {
						gameScreen = "MainMenu";
						locationX = 0;
						locationY = 0;
						this.inputTimer = 7;
						
					}
					else {
						gameScreen = "PartyIDCheck";
						this.inputTimer = 7;
						this.locationXSwap = this.locationX;
					}
				}
			}
			
			
		

		}
		
		else if (gameScreen == "PartyButtons") {
			
			this.x = 200;

			if (locationY > 2) {
				this.locationY = 2;
			}

			else if (locationY < 0) {
				this.locationY = 0;
			}

			if (locationY == 0) {
				this.y = 161 + 112;
				this.imageName = "images/PartySummaryCursor.png";
			} else if (locationY == 1) {
				this.y = 161 + 138 ;
				this.imageName = "images/PartySwitchCursor.png";
			}
			else if ( locationY == 2) {
				this.y = 161 + 164;
				this.imageName = "images/PartyCancelCursor.png";
			}
			
			if (this.inputTimer == 0) {
				if (this.input.contains(this.a)) {
				
					if (locationY == 0) {
						gameScreen = "Summary";
						locationX = 0;
						locationY = 0;
						this.inputTimer = 7;
						
					}
					else if (locationY == 1) {
						gameScreen = "Swap";
						this.inputTimer = 7;
					}
					
					else if (locationY == 2) {
						gameScreen = "Pokemon";
						locationX = 0;
						locationY = 0;
						this.inputTimer = 7;
					}
				}
			}
		}
		
		else if (gameScreen == "Summary") {

			if (locationX > 2) {
				this.locationX = 2;
			}

			else if (locationX < 0) {
				this.locationX = 0;
			}



			if (locationX == 0) {
				this.x = 1000;
				this.y = 1000;
			} else if (locationX == 1) {
				this.x = 98;
				this.y = 161 + 30;
				this.imageName = "images/SummaryScreenInfo.png";
			}
			else if ( locationX == 2) {
				this.x = 98;
				this.y = 161 + 30;
				this.imageName = "images/SummaryScreenMoves.png";
			}
			
			if (this.inputTimer == 0) {
				if (this.input.contains(this.a)) {
						gameScreen = "Pokemon";
						locationX = 0;
						locationY = 0;
						this.inputTimer = 7;

				}
			}
			
			
		

		}

		else if (gameScreen == "Bag") {
			
			this.imageName = "images/BagCursor.png";

			if (locationY > 3) {
				this.locationY = 3;
			}

			else if (locationY < 0) {
				this.locationY = 0;
			}

			if (locationY == 0) {
				this.x = 116;
				this.y = 181;
			} else if (locationY == 1) {
				this.x = 116;
				this.y = 201;
			} else if (locationY == 2) {
				this.x = 116;
				this.y = 221;
			}
			else if (locationY == 3) {
				this.x = 116;
				this.y = 241;
			}
			
			
			if (this.inputTimer == 0) {
				if (this.input.contains(this.a)) {
				
					if (locationY == 0) {
						gameScreen = "ItemMechanicsPlayer";
						this.inputTimer = 7;
						
					}
					else if (locationY == 1) {
						gameScreen = "ItemMechanicsPlayer";
						this.inputTimer = 7;
						
					}
					else if (locationY == 2) {
						gameScreen = "ItemMechanicsPlayer";
						this.inputTimer = 7;
						
					}
				else if (locationY == 3) {
						gameScreen = "MainMenu";
						locationX = 0;
						locationY = 0;
						this.inputTimer = 7;
						
					}
				}
			}
			

		}
		
		else {
			
		}
		
		this.image = new Image(this.imageName);
		this.gc.drawImage(this.image, this.x, this.y); // draws the image on screen
		
		return gameScreen;
	}
}
