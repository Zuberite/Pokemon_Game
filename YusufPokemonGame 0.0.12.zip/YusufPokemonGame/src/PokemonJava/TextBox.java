package PokemonJava;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class TextBox {

	@FXML
	Canvas gameCanvas;

	GraphicsContext gc;

	String textToLoad1 = "What Will Charmander Do?";
	String textToLoad2 = "";
	String textToLoad3 = "";

	public TextBox(GraphicsContext gc, Canvas gameCanvas) {
		super();
		this.gameCanvas = gameCanvas;
		this.gc = gc;
	}

	public Canvas getGameCanvas() {
		return gameCanvas;
	}

	public void setGameCanvas(Canvas gameCanvas) {
		this.gameCanvas = gameCanvas;
	}

	public GraphicsContext getGc() {
		return gc;
	}

	public void setGc(GraphicsContext gc) {
		this.gc = gc;
	}

	public String getTextToLoad1() {
		return textToLoad1;
	}

	public void setTextToLoad1(String textToLoad1) {
		this.textToLoad1 = textToLoad1;
	}

	public String getTextToLoad2() {
		return textToLoad2;
	}

	public void setTextToLoad2(String textToLoad2) {
		this.textToLoad2 = textToLoad2;
	}

	public String getTextToLoad3() {
		return textToLoad3;
	}

	public void setTextToLoad3(String textToLoad3) {
		this.textToLoad3 = textToLoad3;
	}

	public void display() {

		gc.setFont(Font.font("Arial", FontWeight.BOLD, 11));

		gc.setFill(Color.BLACK);
		gc.fillText(textToLoad1, 12, 130);
		gc.setFill(Color.BLACK);
		gc.fillText(textToLoad2, 12, 143);
		gc.setFill(Color.BLACK);
		gc.fillText(textToLoad3, 12, 156);

	}

}
