# Hey! Welcome to my faboulous code
# This code was created by Subbayal Yusuf on June 3, 2019 and completed on June 14, 2019
# This is the code of the game called breakout: blitz. 
# Just like the original breakout game, the purpose of the game is to rally a ball with a paddle and destroy all the bricks on the screen
# The twist to Subbayal's version is that there are levels, powerups and multiplyers compared to the orginal Atari Breakout made by  in 
# Hope you have fun playing this game. For instructions on the game, please read the #README file in the same folder you found this code in

#Imports
import pygame
import sys
import random
pygame.init()


#While loops
mainMenu = True
controlsMenu = False
leaderboardMenu = False
gameStart = False
drawnStatus = False



#Code for Screen
screenX = 1200
screenY = 600
size = (screenX, screenY)
screen = pygame.display.set_mode(size,0)
pygame.display.set_caption("-------------------------------------------------------------------BREAKOUT BLITZ. A game made my Subbayal Yusuf.--------------------------------------------------------------------")


# Arrays
mainMenuButtonNames = ["Play","Controls","Leaderboard","Quit"]
exitButtonNames = ["Quit,Back"]
bricks = []




#Functions

#Draws title on screen
def drawTitle(titlex,titley,titleh,titlew):

    titleImage = pygame.image.load("breakout.jpg")
    titleImage = pygame.transform.scale(titleImage,(titleh,titlew))
    screen.blit(titleImage, (titlex, titley))

def drawMainMenuButtons(mainMenuButtonNames,buttonValue):
    buttonRects = []
    buttonFont = pygame.font.SysFont("arial", 28)
    buttonx = 50
    buttony = 300
    length = len(mainMenuButtonNames)
    for i in range(length): 
        buttony = buttony + 50
        if buttonValue == i:
            buttonText = buttonFont.render(mainMenuButtonNames[i], True, RED)
        else:
            buttonText = buttonFont.render(mainMenuButtonNames[i], True, WHITE)
        buttonRects.append(buttonText.get_rect())
        buttonRects[i].x = buttonx
        buttonRects[i].y = buttony
        screen.blit(buttonText, buttonRects[i])
    return buttonRects

def drawBackButtons(buttonValue):
    buttonFont = pygame.font.SysFont("arial", 28)
    if buttonValue == 5:
        buttonText = buttonFont.render("Back", True, RED)
    else:
        buttonText = buttonFont.render("Back", True, WHITE)
    backButtonRect = buttonText.get_rect()
    backButtonRect.x = 1100
    backButtonRect.y = 550
    screen.blit(buttonText,backButtonRect)
    return backButtonRect

def drawControlsButtons(buttonValue):
    buttonFont = pygame.font.SysFont("arial", 28)
    print(buttonValue)
    if buttonValue == 6:
        keyboardButtonText = buttonFont.render("Keyboard", True, RED)
    else:
        keyboardButtonText = buttonFont.render("Keyboard", True, WHITE)
    if buttonValue == 7:
        mouseButtonText = buttonFont.render("Mouse", True, RED)
    else:
        mouseButtonText = buttonFont.render("Mouse", True, WHITE)
    mouseButtonRect = mouseButtonText.get_rect()
    mouseButtonRect.x = 900
    mouseButtonRect.y = 300
    keyboardButtonRect = keyboardButtonText.get_rect()
    keyboardButtonRect.x = 1000
    keyboardButtonRect.y = 300
    screen.blit(mouseButtonText,mouseButtonRect)
    screen.blit(keyboardButtonText,keyboardButtonRect)
    return mouseButtonRect,keyboardButtonRect


def drawPauseButton(screenX,screenY):
    pauseFont = pygame.font.SysFont("arial", 72)
    quitFont = pygame.font.SysFont("arial", 32)
    pauseInfoText = pauseFont.render("press 'p' to unpause", True, GREEN)
    pauseText = pauseFont.render("Pause", True, GREEN)
    quitInfoText = quitFont.render("Press'Q' to go to the main menu'", True, GREEN)
    screen.blit(pauseText,(screenX/2 - 100,screenY/2))
    screen.blit(pauseInfoText,(320,screenY/2 + 125))
    screen.blit(quitInfoText,(320,200))

def drawPauseTextIngame():
    pauseFont = pygame.font.SysFont("arial", 18)
    pauseText = pauseFont.render("Prees 'P' to pause", True, GREEN)
    screen.blit(pauseText,(1000,550))


#Gets the Cursor Position on screen
def getCursorPosition():
    mouse = 0
    mousePositionPressed = (800,800)
    if event.type == pygame.MOUSEBUTTONDOWN:
        mousePositionPressed = pygame.mouse.get_pos()
        print(mousePositionPressed)
    
    return mousePositionPressed

def getMousePosition():
    mouse = 0
    mousePositionIdlex = 0
    mousePositionIdley = 0
    mousePositionIdlex,mousePositionIdley = pygame.mouse.get_pos()  

    return mousePositionIdlex,mousePositionIdley  

#Checks for any keyboard events in menu


def backButtonCollision(backButtonRect,mousePositionIdlex,mousePositionIdley,mousePositionPressed):
    if backButtonRect.collidepoint(mousePositionIdlex,mousePositionIdley) == True:
        buttonValue = 5
    else:
        buttonValue = -1
    Menu = True
    if backButtonRect.collidepoint(mousePositionPressed) == True:
        Menu = False

    return buttonValue,Menu
        
def controlsButtonsCollision(mouseButtonRect,keyboardButtonRect,mousePositionIdlex,mousePositionIdley,mousePositionPressed,controller):
    if mouseButtonRect.collidepoint(mousePositionIdlex,mousePositionIdley) == True:
        buttonValue = 7
    elif keyboardButtonRect.collidepoint(mousePositionIdlex,mousePositionIdley) == True:
        buttonValue = 6
    else:
        buttonValue = -1
    if mouseButtonRect.collidepoint(mousePositionPressed) == True:
        controller = 1
    if keyboardButtonRect.collidepoint(mousePositionPressed) == True:
        controller = 2

    return buttonValue,controller
    

    

def leaderBoardSizeSwitch(sizeSwitch,size,leaderBoardTitleh,leaderBoardTitlew):
    if sizeSwitch == 1:
            size = size + 1
            leaderBoardTitleh = leaderBoardTitleh + 1
            leaderBoardTitlew = leaderBoardTitlew + 1
    if sizeSwitch == 0:
        size = size -1
        leaderBoardTitleh = leaderBoardTitleh - 1
        leaderBoardTitlew = leaderBoardTitlew - 1

    if size >= 42:
        sizeSwitch = 0
    if size <= 12:
        sizeSwitch = 1
    return sizeSwitch,size,leaderBoardTitleh,leaderBoardTitlew

def buttonCollision(buttonRects,mousePositionIdlex,mousePositionIdley,mousePositionPressed):
    if buttonRects[0].collidepoint(mousePositionIdlex,mousePositionIdley) == True:
        buttonValue = 0
    elif buttonRects[1].collidepoint(mousePositionIdlex,mousePositionIdley) == True:
        buttonValue = 1
    elif buttonRects[2].collidepoint(mousePositionIdlex,mousePositionIdley) == True:
        buttonValue = 2
    elif buttonRects[3].collidepoint(mousePositionIdlex,mousePositionIdley) == True:
        buttonValue = 3
    else:
        buttonValue = -1

    if buttonRects[0].collidepoint(mousePositionPressed) == True:
        gameStart = True
        controlsMenu = False
        leaderboardMenu = False
        mainMenu = True
    elif buttonRects[1].collidepoint(mousePositionPressed) == True:
        gameStart = False
        controlsMenu = True
        leaderboardMenu = False
        mainMenu = True
    elif buttonRects[2].collidepoint(mousePositionPressed) == True:
        gameStart = False
        controlsMenu = False
        leaderboardMenu = True
        mainMenu = True
    elif buttonRects[3].collidepoint(mousePositionPressed) == True:
        gameStart = False
        controlsMenu = False
        leaderboardMenu = False
        mainMenu = False
    else:
        gameStart = False
        controlsMenu = False
        leaderboardMenu = False
        mainMenu = True


    return buttonValue,gameStart,controlsMenu,leaderboardMenu,mainMenu

def drawGameWalls():
    gameWallx = []
    gameWally = []

    rightGameWall = pygame.Rect(25,25,25,550)
    topGameWall = pygame.Rect(50,25,800-25,25)
    bottomGameWall = pygame.Rect(50,550,800-25,25)
    leftGameWall = pygame.Rect(800,25,25,525)

    gameWallx.append(rightGameWall)
    gameWallx.append(leftGameWall)
    gameWally.append(topGameWall)
    gameWally.append(bottomGameWall)
    length = len(gameWallx)
    
    for i in range(length):
        pygame.draw.rect(screen,WHITE,(gameWallx[i]),0)
        pygame.draw.rect(screen,WHITE,(gameWally[i]),0)
    
    return gameWallx,gameWally
        

def drawBricks(bricks,level,bricksDrawn):
    if bricksDrawn == 1:
        if level == 1:
            levelStartBricks = ["WWWWW",
            "WWWWW",
            "WWWWW",
            "     ",
            "     ",
            "     ",
            "     ",
            "     ",
            "     ",
            "     ",
            "     ",
            "     ",
            "     "]
        elif level == 2:
            levelStartBricks = ["WWWWW",
            "WWWWW",
            "WWWWW",
            "     ",
            "     ",
            "     ",
            "WWWWW",
            "WWWWW",
            "     ",
            "     ",
            "     ",
            "     ",
            "     "]
        elif level == 3:
            levelStartBricks = ["WWWWW",
            "     ",
            "WWWWW",
            "     ",
            "WWWWW",
            "     ",
            "WWWWW",
            "     ",
            "WWWWW",
            "     ",
            "WWWWW",
            "     ",
            "     "]
        bricksDrawn = 0

        bricks = []

        x = 50
        y = 50
        for line in levelStartBricks:
            for letter in line:
                if letter == "W":
                    bricks.append(pygame.Rect(x,y,150,500/13))
                x = x + 150
            y = y + 500/13
            x = 50


    length = len(bricks)
    brickSwitch = 0
    for i in range(length):
        if brickSwitch == 0:
            pygame.draw.rect(screen,BREAKOUTBLUE,bricks[i],0)
            brickSwitch = 1
        elif brickSwitch == 1:
            pygame.draw.rect(screen,BREAKOUTPINK,bricks[i],0)
            brickSwitch = 0
    
    return bricks,level,bricksDrawn
        
def drawPaddle(x,y):

    paddleCenterRects = []
    paddleCornerRects = []

    leftCornerPaddleRect = pygame.Rect(x-50-75,y,50,25)
    leftCenterPaddleRect = pygame.Rect(x-75,y,75,25)
    rightCenterPaddleRect = pygame.Rect(x,y,75,25)
    rightCornerPaddleRect = pygame.Rect(x+75,y,50,25)

    paddleCornerRects.append(leftCornerPaddleRect)
    paddleCenterRects.append(leftCenterPaddleRect)
    paddleCenterRects.append(rightCenterPaddleRect)
    paddleCornerRects.append(rightCornerPaddleRect)

    length = len(paddleCenterRects)

    for i in range(length):
        pygame.draw.rect(screen, BREAKOUTPINK,paddleCornerRects[i], 0)
        pygame.draw.rect(screen, BREAKOUTBLUE,paddleCenterRects[i], 0)

    return paddleCornerRects,paddleCenterRects

def drawBall(x,y):
    ballImage = pygame.image.load("ball.png")
    ballImage = pygame.transform.scale(ballImage,(20,20))
    ballRect = ballImage.get_rect()
    ballRect.x = x
    ballRect.y = y
    screen.blit(ballImage,ballRect)

    return ballRect



def movement(paddleCenterx,paddleCenterdx,ballx,bally,balldx,balldy,gameStart,controlsMenu):

    if gameStart == True:
        ballx = ballx + balldx
        bally = bally + balldy
        paddleCenterx = paddleCenterx + paddleCenterdx

    if controlsMenu == True:
        paddleCenterx = paddleCenterx + paddleCenterdx

    return paddleCenterx,ballx,bally 

def collision(ballx,bally,balldx,balldy,ballRect,bricks,gameWallx,gameWally,paddleCenterx,playerPaddleMultiplyer,playerBrickMultiplyer,playerScore,lives):
    playerScore = playerScore
    brickBroken = 0

    length = len(bricks)

    for i in range(length):
        if brickBroken == 1:
            brickBroken = 1
        elif ballRect.colliderect(bricks[i]) == True:
            if ballRect.collidepoint(bricks[i].midright) or  ballRect.collidepoint(bricks[i].midleft): 
                bricks.pop(i)
                balldx = -balldx
                brickBroken = 1
                playerScore = playerScore + (1*playerBrickMultiplyer*playerPaddleMultiplyer)
                playerBrickMultiplyer = playerBrickMultiplyer + 1
            else:
                bricks.pop(i)
                balldy = -balldy
                brickBroken = 1
                playerScore = playerScore + (1*playerBrickMultiplyer*playerPaddleMultiplyer)
                playerBrickMultiplyer = playerBrickMultiplyer + 1
    

    if ballRect.colliderect(gameWallx[0]) == True:
        balldx = -balldx
    if ballRect.colliderect(gameWallx[1]) == True:
        balldx = -balldx
    if ballRect.colliderect(gameWally[0]) == True:
        balldy = -balldy
    if ballRect.colliderect(gameWally[1]) == True:
        lives = lives - 1
        ballx = paddleCenterx
        bally = 524
        balldx = 2
        balldy = -4
        playerPaddleMultiplyer = 0
        

    
    
    if ballRect.colliderect(paddleCenterRects[0]) == True:
        balldy = -4
        balldx = -2
        playerBrickMultiplyer = 1
        playerPaddleMultiplyer = playerPaddleMultiplyer + 1

    if ballRect.colliderect(paddleCenterRects[1]) == True:
        balldy = -4
        balldx = 2
        playerBrickMultiplyer = 1
        playerPaddleMultiplyer = playerPaddleMultiplyer + 1
        
    if ballRect.colliderect(paddleCornerRects[0]) == True:
        balldy = -2
        balldx = -4
        playerBrickMultiplyer = 1
        playerPaddleMultiplyer = playerPaddleMultiplyer + 1

    if ballRect.colliderect(paddleCornerRects[1]) == True:
        balldy = -2
        balldx = 4
        playerBrickMultiplyer = 1
        playerPaddleMultiplyer = playerPaddleMultiplyer + 1
    
    return paddleCenterx,balldx,balldy,ballx,bally,playerPaddleMultiplyer,playerBrickMultiplyer,playerScore,lives

            



def drawPlayerMenu(playerScore,lives):
    smallFont = pygame.font.SysFont("arial", 18)
    mediumFont = pygame.font.SysFont("arial", 32)

    playerScore = str(playerScore)
    lives = str(lives)

    pauseText = smallFont.render("Prees 'P' to pause", True, GREEN)
    scoreInfoText = mediumFont.render("Score:", True, GREEN)
    scoreText = mediumFont.render(playerScore, True, GREEN)
    livesInfoText = mediumFont.render("Lives:", True, GREEN)
    livesText = mediumFont.render(lives, True, GREEN)
    
    screen.blit(pauseText,(1000,550))
    screen.blit(scoreText,(1000,50))
    screen.blit(scoreInfoText,(900,50))
    screen.blit(livesText,(1000,100))
    screen.blit(livesInfoText,(900,100))

def updateLeaderboard(leaderboardScores,playerScore):
    updated = 0
    newLeaderbboardScores = leaderboardScores

    lenght = len(leaderboardScores)

    for i in range(lenght):
        if updated == 1:
            updated = updated
        elif playerScore == int(leaderboardScores[i]):
            i = i + 1
            newLeaderbboardScores[i] = playerScore
            leaderboardScores = newLeaderbboardScores[0:(i+1)] + leaderboardScores[i:]
            leaderboardScores.pop(20)
            updated = 1
        elif playerScore >= int(leaderboardScores[i]):
            newLeaderbboardScores[i] = playerScore
            leaderboardScores = newLeaderbboardScores[0:(i+1)] + leaderboardScores[i:]
            leaderboardScores.pop(20)
            updated = 1


def drawGameWin(score):
    mediumFont = pygame.font.SysFont("arial", 32)
    largeFont = pygame.font.SysFont("arial", 72)
    winText = largeFont.render("You Beat All the Levels", True, GREEN)
    scoreInfoText = mediumFont.render("Score:", True, GREEN)
    scoreText = mediumFont.render(str(score), True, GREEN)
    quitText = mediumFont.render("To go to Main Menu, press 'Q'", True, GREEN)

    screen.blit(quitText,(25,25))
    screen.blit(winText,(250,300))
    screen.blit(scoreInfoText,(550,500))
    screen.blit(scoreText,(650,500))



def storeleaderboard(leaderboardPositions,leaderboardScores):
    fileName = "Leaderboard.txt"
    openFile = open(fileName,"w")
    intergerLine = ""
    length = len(leaderboardPositions)
    for i in range(length):
        intergerLine = intergerLine + leaderboardPositions[i] + " "
    openFile.write(intergerLine + "\n")
    intergerLine = ""
    print(leaderboardScores)
    for i in range(length):
        intergerLine = intergerLine + str(leaderboardScores[i]) + " "
    openFile.write(intergerLine)
    intergerLine = ""

    openFile.close()
    
    pass

def getLeaderboard():
        fileName = "Leaderboard.txt"
        openFile = open(fileName,"r")
        lineNumber = 0

        leaderboardPositions = []
        leaderboardScores = []

        for line in openFile:
            line = line.strip()
            lineNumber = lineNumber + 1
            for string in line.split(" "):
                if lineNumber == 1:
                    leaderboardPositions.append(string)
                if lineNumber == 2:
                    leaderboardScores.append(string)

        
        openFile.close()
        
        return leaderboardPositions,leaderboardScores

leaderboardPositions,leaderboardScores = getLeaderboard()

def displayLeaderboard(leaderboardPositions,leaderboardScores,size):

    font = pygame.font.SysFont("arial", size)
    positionx = 200
    positiony = 0
    scorex = 300
    scorey = 0
    i = 0
    length = len(leaderboardPositions)
    for i in range(length):
        if i == 0:
            positionText = font.render(str(leaderboardPositions[i]), True, GOLD)
        elif i == 1:
            positionText = font.render(str(leaderboardPositions[i]), True, SILVER)
        elif i == 2:
            positionText = font.render(str(leaderboardPositions[i]), True, BRONZE)
        else:
            positionText = font.render(str(leaderboardPositions[i]), True, WHITE)
        positiony = positiony + 50
        if i == 10:
            positionx = 800
            positiony = 50
        screen.blit(positionText, (positionx, positiony))
    for i in range(length):
        if i == 0:
            scoreText = font.render(str(leaderboardScores[i]), True, GOLD)
        elif i == 1:
            scoreText = font.render(str(leaderboardScores[i]), True, SILVER)
        elif i == 2:
            scoreText = font.render(str(leaderboardScores[i]), True, BRONZE)
        else:
            scoreText = font.render(str(leaderboardScores[i]), True, WHITE)
        scorey = scorey + 50
        if i == 10:
            scorex = 900
            scorey = 50
        screen.blit(scoreText, (scorex, scorey))

    pass


buttonValue = -1

#Preset Colours
WHITE = (255,255,255)
RED = (255,0,0)
ORANGE = (255,165,0)
YELLOW = (255,255,0)
GREEN = (0,255,0)
BLUE = (135,206,250)
INDIGO = (0,0,255)
VIOLET = (128,0,128)
BLACK = (0,0,0)

GOLD = (255,215,0)
SILVER = (192,192,192)
BRONZE = (205,127,50)

BREAKOUTBLUE = (42,211,250)
BREAKOUTPINK = (247,24,115)

#

size = 28
sizeSwitch = 1
FPS = 400
clock = pygame.time.Clock()
leaderBoardTitleh = 273
leaderBoardTitlew = 160
paddleCenterx = 750/2 + 50
paddleCentery = 525
paddleCenterdx = 0
ballx = 500
bally = 500
balldx = 2
balldy = -4
level = 1
bricksDrawn = 1
pauseValue = 0
pauseSwitch = 0
lives = 3
controller = 1
buttonValue2 = -1

FPS = 60



while mainMenu:
    mousePositionPressed = (2400,2400)
    for event in pygame.event.get():
        # we get mouse positon when clicked
        mousePositionPressed = getCursorPosition()
        if event.type == pygame.quit:
            mainMenu = False
        if event.type ==pygame.KEYDOWN:
            if event.key == pygame.K_q:
                mainMenu = False


    clock.tick(FPS)
    
    gameWinValue = 0
    playerScore = 0
    playerPaddleMultiplyer = 1
    playerBrickMultiplyer = 1
    pauseSwitch = 0
    pauseValue = 0
    bricksDrawn = 1
    lives = 3
    level = 1
    ballx = 375
    bally = 524
    FPS = 50
    clock.tick(FPS)
    score = 0

    
    
    screen.fill(BLACK)
    mousePositionIdlex,mousePositionIdley = getMousePosition()
    drawTitle(50,50,273,160)
    #we draw the title and return the button rects
    buttonRects = drawMainMenuButtons(mainMenuButtonNames,buttonValue)
    buttonValue,gameStart,controlsMenu,leaderboardMenu,mainMenu = buttonCollision(buttonRects,mousePositionIdlex,mousePositionIdley,mousePositionPressed)


    # we check to see if the clicked mouse position collides with any of the button rects

    pygame.display.update()
    
    while controlsMenu:
        mousePositionIdlex,mousePositionIdley = getMousePosition()
        mousePositionPressed = (2400,2400)

        if controller == 1:
            paddleCenterx = mousePositionIdlex

        for event in pygame.event.get():
            # we get mouse positon when clicked
            mousePositionPressed = getCursorPosition()
            if event.type == pygame.quit:
                mainMenu = False
            if event.type ==pygame.KEYDOWN:
                if event.key == pygame.K_q:
                        gameStart = False
                if event.key == pygame.K_RIGHT:
                    if controller == 2:
                        paddleCenterdx = 4
                if event.key == pygame.K_LEFT:
                    if controller == 2:
                        paddleCenterdx = -4
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    paddleCenterdx = 0

        FPS = 200
        clock.tick(FPS)

        rightWallx = 675
        leftWallx = 175
        paddleCenterx = paddleCenterx
        if paddleCenterx >= rightWallx:
            paddleCenterx = 675
        if paddleCenterx <= leftWallx:
            paddleCenterx = 175

        paddleCenterx,ballx,bally = movement(paddleCenterx,paddleCenterdx,ballx,bally,balldx,balldy,gameStart,controlsMenu)
        screen.fill(BLACK)
        drawGameWalls()
        drawPaddle(paddleCenterx,paddleCentery)
        backButtonRect = drawBackButtons(buttonValue)
        mouseButtonRect,keyboardButtonRect = drawControlsButtons(buttonValue2)
        buttonValue,controlsMenu = backButtonCollision(backButtonRect,mousePositionIdlex,mousePositionIdley,mousePositionPressed)
        buttonValue2,controller = controlsButtonsCollision(mouseButtonRect,keyboardButtonRect,mousePositionIdlex,mousePositionIdley,mousePositionPressed,controller)
        pygame.display.update()
    
    while leaderboardMenu:
        mousePositionPressed = (2400,2400)
        for event in pygame.event.get():
            # we get mouse positon when clicked
            mousePositionPressed = getCursorPosition()
            if event.type == pygame.quit:
                mainMenu = False
            if event.type ==pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    leaderboardMenu = False
                    mainMenu = False

        sizeSwitch,size,leaderBoardTitleh,leaderBoardTitlew = leaderBoardSizeSwitch(sizeSwitch,size,leaderBoardTitleh,leaderBoardTitlew)

        FPS = 35
        clock.tick(FPS)

        screen.fill(BLACK)

        mousePositionIdlex,mousePositionIdley = getMousePosition()

        backButtonRect = drawBackButtons(buttonValue)
        buttonValue,leaderboardMenu = backButtonCollision(backButtonRect,mousePositionIdlex,mousePositionIdley,mousePositionPressed)

        drawTitle(500,200,leaderBoardTitleh,leaderBoardTitlew)
        displayLeaderboard(leaderboardPositions,leaderboardScores,size)
        pygame.display.update()

    while gameStart:
        if level >= 4:
            gameWinValue = 1
        mousePositionIdlex,mousePositionIdley = getMousePosition()
        mousePositionPressed = (2400,2400)

        if controller == 1:
            paddleCenterx = mousePositionIdlex

        for event in pygame.event.get():
            # we get mouse positon when clicked
            mousePositionPressed = getCursorPosition()
            if event.type == pygame.quit:
                mainMenu = False
            if event.type ==pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    if pauseSwitch == 1:
                        gameStart = False
                if event.key == pygame.K_RIGHT:
                    if controller == 2:
                        paddleCenterdx = 4
                if event.key == pygame.K_LEFT:
                    if controller == 2:
                        paddleCenterdx = -4
                if event.key == pygame.K_p:
                    if pauseSwitch == 0:
                        pauseValue = 1
                        pauseSwitch = 1
                    elif pauseSwitch == 1:
                        pauseValue = 0
                        pauseSwitch = 0
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    paddleCenterdx = 0
        if gameWinValue == 1:
            pauseSwitch = 1
            screen.fill(BLACK)
            drawGameWin(score)
            pygame.display.update()

        else:
            if pauseValue == 0:
                FPS = 50
                clock.tick(FPS)
                
                rightWallx = 675
                leftWallx = 175
                paddleCenterx = paddleCenterx
                if paddleCenterx >= rightWallx:
                    paddleCenterx = 675
                if paddleCenterx <= leftWallx:
                    paddleCenterx = 175

                screen.fill(BLACK)
                drawTitle(750/2-60,500/2-20,273,160)
                gameWallx,gameWally = drawGameWalls()
                paddleCornerRects,paddleCenterRects = drawPaddle(paddleCenterx,paddleCentery)
                bricks,level,bricksDrawn = drawBricks(bricks,level,bricksDrawn)
                ballRect = drawBall(ballx,bally)

                drawPlayerMenu(playerScore,lives)

                paddleCenterx,balldx,balldy,ballx,bally,playerPaddleMultiplyer,playerBrickMultiplyer,playerScore,lives = collision(ballx,bally,balldx,balldy,ballRect,bricks,gameWallx,gameWally,paddleCenterx,playerPaddleMultiplyer,playerBrickMultiplyer,playerScore,lives)
                paddleCenterx,ballx,bally = movement(paddleCenterx,paddleCenterdx,ballx,bally,balldx,balldy,gameStart,controlsMenu)
            else: 
                screen.fill(BLACK)
                drawPauseButton(screenX,screenY)

            if lives == 0:
                updateLeaderboard(leaderboardScores,playerScore)
                gameStart = False
            
            length = len(bricks)
            if length == 0:
                ballx = paddleCenterx
                bally = 524
                bricksDrawn = 1
                level = level + 1



            pygame.display.update()



storeleaderboard(leaderboardPositions,leaderboardScores)
pygame.quit()
sys.exit()

