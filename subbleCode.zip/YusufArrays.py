# Welcome to Subbayal Yusuf's List and Arrays Assignment
# Completed on May,15 2019.
# This python file contrains the code for all the buttons required in the creteria of this assignment
# It uses a secondairy file pygame_textinput.py to run the code along side the pygame template made by the teacher
# Enjoy!
# Some of the lines of code are repeated, so I just commented them once in the code



""" Strings and Files Template
    ** once you download this file - resave it as
    <yourname>StringsAndFiles.py
    This program has the menu completed for the assignments
    The menu works with both mouse or arrow key input
    Your task is to fill in the missing functions
"""

import pygame
import sys
import pygame_textinput  # need this for text input in pygame
import random

# initialize pygame
pygame.init()

# set screen size
size = (800, 675)
screen = pygame.display.set_mode(size)
#------------------------methods--------------------------------------------
#menu function method
#prints menu selection and only exits after a choice has been made
def menu(titles):
    startY = 25
    spaceY = 40
    mainTitleFont = pygame.font.SysFont("arial", 72)
    buttonTitleFont = pygame.font.SysFont("arial", 24)
    selection = []
    rectWidth = 300
    rectHeight = 30
    x = int(screen.get_width()/2 - rectWidth/2)
    y = startY
    length = len(titles)
    num = 0
    hover = False
    # creates the Rects (containers) for the buttons
    for i in range (0,length,1):
        choiceRect = pygame.Rect(x,y,rectWidth,rectHeight)
        selection.append(choiceRect)
        y += spaceY

    #main loop in menu    
    go = True
    while go:    
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                go = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    go = False
                    pygame.quit()
                    sys.exit()
                elif event.key == pygame.K_UP:
                    num -= 1                # if up arrow pressed move up one by changing num
                    if num < 0:             # make sure num doesn't go out of range
                        num = length-1
                elif event.key == pygame.K_DOWN:
                    num += 1                # if down arrow pressed move down by changing num
                    if num > length-1:      # make sure num doesn't go out of range
                        num = 0
                elif event.key == pygame.K_RETURN:
                    go = False              # if they hit Enter then exit the loop
            if event.type ==pygame.MOUSEMOTION:     # if mouse moved
                hover = False
                mx, my = pygame.mouse.get_pos()     # get the mouse position
                for i in range (length):            
                    if selection[i].collidepoint((mx,my)):  # check if x,y of mouse is in a button
                        num = i
                        hover = True
            if event.type == pygame.MOUSEBUTTONDOWN and hover == True:  #if mouse is in button
                go = False                                              # and has been clicked

        # draw all buttons                                                                
        for choice in selection:
            pygame.draw.rect(screen,RED,choice,0)
        
        # redraw selected button in another colour
        pygame.draw.rect(screen,GREEN,selection[num],0)
        
        # draw all the titles on the buttons
        x = int(screen.get_width()/2 - 150)
        y = startY
        for i in range(0,length,1):
            buttonTitle = buttonTitleFont.render(titles[i],True,WHITE)
            screen.blit(buttonTitle,(x,y))
            y += spaceY

        pygame.display.update()
    return num

# simply used anywhere in the program a pause is needed
def pause():
    go = True
    while go:    
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    go = False
       
        returnFont = pygame.font.SysFont('comicsansms',30)
        returnText = returnFont.render("Press Enter To Continue",True,RED)
        x = getHorizontalCentre(returnText)
        screen.blit(returnText, (x,300))
        pygame.display.update()

# to centre text horizontally
def getHorizontalCentre(textRendered):
    screenCentre = screen.get_width()/2
    textWidth = textRendered.get_width()/2
    x = int(screenCentre - textWidth)
    return x


# displays string to screen,  can add more choices if you like
# i.e. font size, colour, x position
def displayString(y,message):
    screen.fill(WHITE)        
    displayFont = pygame.font.SysFont("arial", 12)
    messageText = displayFont.render(message,True,BLACK)
    x = getHorizontalCentre(messageText)
    screen.blit(messageText,(x,y))
    pygame.display.update()
    pause()

def checkInt(number, message):

    while True:
        try:
            intNum = int(number)
            break
        except ValueError:
            number = getUserText(message)
    return intNum


# uses the pygame_textinput class to get user input (typed)
# after the user hits Enter it will return the string the user typed in
def getUserText(message):
    # Create TextInput-object
    textInput = pygame_textinput.TextInput()
    clock =pygame.time.Clock()
    go = True
    while go:
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        screen.fill(WHITE)
        clock.tick(30)
       
        inputFont = pygame.font.SysFont('comicsansms',30)
        inputText = inputFont.render(message,True,RED)
        x = getHorizontalCentre(inputText)
        screen.blit(inputText, (x,300))

        # Blit its surface onto the screen
        screen.blit(textInput.get_surface(), (x,250))
        if textInput.update(events) == True:
            userInput =textInput.get_text()
            go = False
        pygame.display.update()

    return userInput

def openNewFile(fileName, readWrite):
    inputFont = pygame.font.SysFont('comicsansms',30)
    if readWrite == "read":
        io = "r"
    elif readWrite == "write":
        io = "w"

    while True:
        try:
            newFile = open(fileName, io)
            break
        except FileNotFoundError:
            screen.fill(WHITE)
            errorMessage = "Sorry, can't find: "+ fileName
            fileLine = inputFont.render(errorMessage,True,RED)
            screen.blit(fileLine, (100,200))
            pygame.display.update()
            pause()
            fileName = getUserText("Please input file name again")
    
    return newFile

# Array Functions----------------------------------------------------------
def enterInt():
    getInt = True
    array = []
    screen.fill(WHITE)
    displayString(100,"Enter positive integers, enter a negative one to end")
    while getInt == True:
        numStr = getUserText("Enter a positive integer (negative to end)")
        num = checkInt(numStr, "Sorry that's not an integer, try again")
        if num >= 0:
            array.append(num)
        else:
            getInt = False
    return array


def displayArray(array): #displays the array
    message = "" # the varaible that holds the array as a string
    
    # Adds each __ in an array to the message
    length = len(array)
    if length != 0: 
        for i in range(length):
            message = message + str(array[i]) + " "
    else: #done if no array was entered
        message = "Please enter an array first"
    
    return message

def countIntegers(array): #counts the number of intergers in the array
    length = len(array)# counts the number of intergers in the array
    if length != 0: # creates a message for the user that tells the # of intergers in the array
        message = "There are " + str(length) + " integers in the array" 
    else:  #done i no array was entered
        message = "Please enter an array first"
    return message

def displayArrayReverse(array): #displays the array in reverse
    array = array[::-1] # reverses the order in the array
    message = displayArray(array)  # turn the array into a string
    return message
    
def sumArray(array): #adds the values of the intergers in the array
    sumOfArray = 0 # variable that holds the sum of the intergers in the arry
    
    # same as displayArray, but instead of getting each interger and making a string, we add the intergers together
    message = ""
    length = len(array)
    if length != 0:
        for i in range(length):
            sumOfArray = sumOfArray + int(array[i])
    else: 
        message = "Please enter an array first"

    # converts the sumOfArray into a string so that it can be displayed. 
    message = str(sumOfArray) 

    return message

def averageArray(array): #Finds the average value of the integers in the array
    sumOfArray = 0
    numberOfIntergers = 0 # Counts the number of integers to devide by
    message = ""

    #The same as sumArray, but we devide by the total intergers to get the average
    length = len(array)
    if length != 0:
        for i in range(length):
            sumOfArray = sumOfArray + int(array[i])
            numberOfIntergers = numberOfIntergers + 1
    else: 
        message = "Please enter an array first"
    avgOfArray = round(sumOfArray / numberOfIntergers, 2)

    message = str(avgOfArray)

    return message

def findMaxMinArray(array): #finds the minimum and maxiumum interger value in the array
    message = ""
    length = len(array)
    length = length + 1 #we set the max and min as the first interger so we add 1 to the lenght to skip over the first interger and start at the 2nd
    maxValue = array[0] # sets the first value to the max and min so that we don't get an error at the start
    minValue = array[0]
    if length != 0:
        for i in range(length):
            # if the current interger is more than maxValue, set that to maxValue
            if array[i] > maxValue:
                maxValue = array[i]
            # if the current interger is less than miValue, set that to minValue
            if array[i] < minValue:
                minValue = array[i]
    else: 
        message = "Please enter an array first"

    # Creates a message telling the user the max and min value
    message = "Min Value is " + str(minValue) + " and Max Value is " + str(maxValue)

    return message

def searchArray(array): #searches the array for a number, if it finds it, it says true, else it says false

    length = len(array)
    if length != 0:
        numberInStr = True
        numStr = getUserText("Enter a positive integer to search for")

        #Checks if the interger is in the string and then converts that position into a string
        while numberInStr == True:
            numberInStr = False
            try: 
                locationOfInterger = array.index(int(numStr))
            except:  
                message = "False, that interger is not in the array"

        message = "True, That interger is located at position ", str(locationOfInterger)
    else:
        message = "Please enter an array first"

    return message

def writeArrayToFile(array): #writes the given array to a file

    intergerLine = ""
    lenght = len(array)

    #Writes each integer to the line
    if lenght != 0:
        for i in range(lenght):
            intergerLine = intergerLine + str(array[i]) + " " #add the interger to a line followed by a space
        
        #opens an writes said line to a file, the closes the file
        fileName = getUserText("Enter filename (with extension)")
        userFile = open(fileName, "w")
        userFile.write(intergerLine) 
        userFile.close()
    else:
        message = "Please enter an array first"

    return message
    ## don't forget to close the file after you are done

def readArrayFromFile(): #reads an array from a file
    realFile = True
    array = []
    # asks the user for a file
    fileName = getUserText("Enter the name of the file you want to read array from")
    while realFile:
        realFile = False
        try:
            openFile = open(fileName,"r")
        except: #prevent user not entering an actual file
            fileName = getUserText("that's not a file name")
            realFile = True

    #iterates over the file by line
    for line in openFile:
        line = line.strip()
    #iterates over the line by interger 
        for interger in line.split(' '):
            array.append(interger) #adds each interger is the array

    print(array)
    openFile.close()
    message = displayArray(array) # Converts the array into a string to display as a message
    
    return message, array


    # return the array when you are done

def searchAndReplace(array): #Finds an interger in the array and replaces it with a new interger both given by the user

    length = len(array)

    if length != 0:
        numberInStr = True
        newNumberIsStr = True

        #asks the user for a number in the string
        numStr = getUserText("Enter a positive integer to search for")
        while numberInStr == True:
            numberInStr = False
            try:
                locationOfInterger = array.index(int(numStr))
            except: 
                # to prevent the user from enter a number that is not in the array
                numStr = getUserText("that's not a number in the string, try again")
                numberInStr = True

        #asks the user for a new number
        replaceStr = getUserText("Enter a new postive interger to replace with ")
        while newNumberIsStr == True:
            newNumberIsStr = False
            try:
                array[locationOfInterger] = int(replaceStr)
            except:
                # to prevent the user from entering nothing
                replaceStr = getUserText("that's not a number, please try again")
                newNumberIsStr = True

        message = displayArray(array)
    else:
        message = "Please enter an array first"

    return message 



def shuffleArray(array): #Shuffles the arrays values around

    length = len(array)
    if length != 0:
        randomizer = True
        newArray = []
        length = len(array)
        lengthArray = length - 1

        while randomizer: 
            i = random.randint(0,lengthArray) # chooses a random interger from the array
            newArray.append(array[i]) #adds that integer to the newArray
            print(newArray)
            array.pop(i) # takes away the integer from the old array
            lengthArray = lengthArray - 1 # decrese the amount of integers so that when it randomizes again, it doesn't get a value where an interger doesn't exist
            length = length - 1 # Checks for array lenght, and decreases by 1 when the array gets smaller, so that when it = 0, the while loop ends
            if length == 0:
                randomizer = False

        message = displayArray(newArray)
    else:
        message = "Please enter an array first"
        newArray = array

    return message, newArray
    #remember don't use the built in shuffle command


def countWordsInFile(): #reads a user text file and counts the number for the occurance of each word 

    #we ignore this as we only want to get an array from the file not the message
    toIgnore, array = readArrayFromFile()
    length = len(array)
    newArray = []
    
    if length != 0:

        for word in range(length):
            #records the amount of times the word at i occurs in the array
            count = array.count(array[word])
            # coverts each word at the respective i above into a string to check if it's added in the new array
            wordString = str(array[word])
            # skips adding the word to the array string if it and it's count is already recorded in the new array
            if wordString in newArray:
                print("already added")
            else:
            #Adds a section for the new word, followed by the count that was recorded in the original array from the file
                print("new word")
                newArray.append(str(array[word]))
                newArray.append('occurs in the file ')
                newArray.append(count)
                newArray.append("times")

        message = " "       
        message = str(newArray)

    else:
        message = "Please enter an array first"

        
    return message
    
    #you need to plan this one out before you code
    # create two arrays,  one for the words and one for the number of occurances of the word

def addIntToArray(array):

    length = len(array)
    if length != 0:
        numberInt = True
        addInt = getUserText("Enter a positive integer to add")

        #Adds the interger to the string unless it is not a positive interger
        while numberInt == True:
            numberInt = False
            if addInt >= 0:
                try: 
                    array.append(int(addInt))
                    print(array)
                except:  
                    addInt = getUserText("that is not a postive integer")
                    numberInt = True

        message = displayArray(array)
    else:
        message = "Please enter an array first"

    return message, array

def removeFromArray(array):
    
    length = len(array)
    if length != 0:
        numberInt = True
        removeInt = getUserText("Enter a positive integer to remove")

        #Checks for the integer in the array each time, 
        # once it is unable to index the integer, 
        # this is a sign all the intergers are gone from the array 
        # and we exist the loop
        while numberInt == True:
            numberInt = False
            print(array)
            try: 
                intToRemove = array.index(int(removeInt))
                array.pop(intToRemove)
                numberInt = True
            except:  
                pass        

        message = displayArray(array)
    else:
        message = "Please enter an array first"

    print(array)

    return message, array





# main program -----------------------------------------------------------

# colours
RED = (255, 0, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
BLUE = (0,0,255)

# titles for  menu
menuMain = ["Enter Integers","Display Array","Count Integers In Array","Display Array In Reverse","Sum Integers in Array","Find Average of Array Integers","Find Max and Min","Search for Integer","Write Array to File","Fill Array from File","Search and Replace Integer","Shuffle the Array","Count Words in File","Add interger to array","Remove integer to array","QUIT"]

screen.fill(WHITE)

mainMenu = True
newArray = [3,3,4]
newString = ""
# main loop
main = True
while main:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            main = False

    screen.fill(WHITE)

    # for main menu, this menu selects the submenu or quits program
    # call string menu to display it and choose an option
    choose = menu(menuMain)
    # the last option returns to main menu
    if choose == len(menuMain)-1:
        main = False
    else:
        if choose == 0:  # option to get user input
            newArray = enterInt()
        elif choose == 1: # option for countCharacters funtion
            newString = displayArray(newArray)
        elif choose == 2:  # option for switchFirstAndLast function
            newString = countIntegers(newArray)
        elif choose == 3:
            newString = displayArrayReverse(newArray)
        elif choose == 4:
            newString = sumArray(newArray)
        elif choose == 5:
            newString = averageArray(newArray)
        elif choose == 6:
            newString = findMaxMinArray(newArray)
        elif choose == 7:
            newString = searchArray(newArray)
        elif choose == 8:
            newString = writeArrayToFile(newArray)
        elif choose == 9:
            newString, newArray = readArrayFromFile()
        elif choose == 10:
            newString = searchAndReplace(newArray)
        elif choose == 11:
            newString, newArray = shuffleArray(newArray)
        elif choose ==12:
            newString = countWordsInFile()
        elif choose ==13:
            newString, newArray = addIntToArray(newArray)
        elif choose ==14:
            newString, newArray = removeFromArray(newArray)
        
        
        
        #display result of function
        displayString(150, newString)
        newString = ""
                         
    pygame.display.update()

pygame.QUIT
sys.exit()
